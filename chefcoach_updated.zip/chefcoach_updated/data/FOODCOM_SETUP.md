# Food.com RAG Data Setup

This project expects Food.com files in this folder:

- `data/RAW_recipes.csv` (required)
- `data/RAW_interactions.csv` (optional, used for rating enrichment)

## 1) Download data

Use Kaggle website or Kaggle CLI to get a Food.com dataset that includes
`RAW_recipes.csv` and `RAW_interactions.csv`.

If you use CLI:

```bash
# one-time auth setup
mkdir -p ~/.kaggle
# put kaggle.json into ~/.kaggle/kaggle.json
chmod 600 ~/.kaggle/kaggle.json

# download into this data folder (replace <owner>/<dataset> with your chosen Food.com dataset)
cd /Users/rui/Desktop/EECS6895/chef_agent/chefcoach/data
kaggle datasets download -d <owner>/<dataset> -p .
unzip "*.zip"
```

## 2) Place files

Make sure these paths exist exactly:

- `/Users/rui/Desktop/EECS6895/chef_agent/chefcoach/data/RAW_recipes.csv`
- `/Users/rui/Desktop/EECS6895/chef_agent/chefcoach/data/RAW_interactions.csv` (optional)

## 3) Set subset size

In `.env`, set:

```env
RECIPE_SUBSET_SIZE=20000
```

For local test speed, use 3000-8000 first. For final demo, use 20000-50000.

## 4) Rebuild index

```bash
cd /Users/rui/Desktop/EECS6895/chef_agent/chefcoach
source .venv/bin/activate
python setup_rag.py
```

After success, check:

- `/Users/rui/Desktop/EECS6895/chef_agent/chefcoach/chroma_db/`
- `/Users/rui/Desktop/EECS6895/chef_agent/chefcoach/data/index_summary.json`

The summary includes:

- `source` (`foodcom_csv` or fallback)
- `recipe_subset_size_config`
- `total_recipes_indexed`
- `recipes_with_rating` (if interactions file is provided)
- `avg_rating_in_indexed_set`

## 5) Optional cleanup

After extracting CSVs, you can remove the downloaded ZIP files to save disk:

- `RAW_recipes.csv.zip`
- `RAW_interactions.csv.zip`
