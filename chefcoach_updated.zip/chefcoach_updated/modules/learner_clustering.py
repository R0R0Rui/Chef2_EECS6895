"""learner_clustering.py

Simple, deterministic learner clustering for personalization.

Clusters:
- C1: Foundation Starter
- C2: Busy Beginner
- C3: Steady Builder
- C4: Advanced Explorer
"""

from __future__ import annotations

from datetime import datetime, timedelta
from typing import Any, Dict, List


def _clamp(x: float, lo: float = 0.0, hi: float = 1.0) -> float:
    return max(lo, min(hi, x))


def _safe_avg(values: List[float], default: float = 0.0) -> float:
    clean = [float(v) for v in values if v is not None]
    if not clean:
        return float(default)
    return sum(clean) / len(clean)


def _experience_score(level: str) -> float:
    mapping = {"beginner": 0.15, "intermediate": 0.55, "advanced": 0.9}
    return mapping.get(str(level or "").strip().lower(), 0.35)


def _recent_session_rate(sessions: List[Dict[str, Any]], days: int = 14) -> float:
    if not sessions:
        return 0.0
    cutoff = datetime.now() - timedelta(days=max(1, days))
    recent = 0
    for s in sessions:
        ts = str(s.get("created_at", "")).strip()
        if not ts:
            continue
        try:
            dt = datetime.fromisoformat(ts)
        except Exception:
            continue
        if dt >= cutoff:
            recent += 1
    # Cap at 1.0 once the user has >= 7 sessions in recent window.
    return _clamp(recent / 7.0)


def build_feature_vector(profile: Dict[str, Any], sessions: List[Dict[str, Any]]) -> Dict[str, float]:
    """Build a compact numeric feature vector from profile + recent sessions."""
    skills = profile.get("skill_vector", {}) or {}
    confidences = profile.get("skill_confidence", {}) or {}
    constraints = profile.get("constraints", {}) or {}

    mastery_avg = _safe_avg([float(v) for v in skills.values()], default=0.0)
    confidence_avg = _safe_avg([float(v) for v in confidences.values()], default=0.5)

    feedbacks = [(s.get("feedback") or {}) for s in (sessions or [])]
    rating_avg = _safe_avg([float(f.get("rating", 3) or 3) for f in feedbacks], default=3.0)
    difficulty_avg = _safe_avg([float(f.get("difficulty", 3) or 3) for f in feedbacks], default=3.0)
    quiz_avg = _safe_avg([float(f.get("quiz_score", 0.5) or 0.5) for f in feedbacks], default=0.5)
    completion_rate = _safe_avg(
        [1.0 if f.get("completed", True) else 0.0 for f in feedbacks],
        default=1.0,
    )

    time_budget = float(constraints.get("time_budget_minutes", 30) or 30)
    time_budget_norm = _clamp((time_budget - 15.0) / 105.0)

    feat = {
        "mastery_avg": round(_clamp(mastery_avg), 4),
        "confidence_avg": round(_clamp(confidence_avg), 4),
        "rating_avg_norm": round(_clamp((rating_avg - 1.0) / 4.0), 4),
        "difficulty_pref_norm": round(_clamp((difficulty_avg - 1.0) / 4.0), 4),
        "quiz_avg": round(_clamp(quiz_avg), 4),
        "completion_rate": round(_clamp(completion_rate), 4),
        "experience_score": round(_clamp(_experience_score(profile.get("experience_level", ""))), 4),
        "time_budget_norm": round(time_budget_norm, 4),
        "recent_session_rate": round(_recent_session_rate(sessions or []), 4),
        "session_count_norm": round(_clamp((profile.get("total_sessions", 0) or 0) / 20.0), 4),
    }
    return feat


def assign_cluster(feature_vector: Dict[str, float]) -> str:
    """Rule-based cluster assignment for stable demo behavior."""
    m = float(feature_vector.get("mastery_avg", 0.0) or 0.0)
    c = float(feature_vector.get("confidence_avg", 0.5) or 0.5)
    q = float(feature_vector.get("quiz_avg", 0.5) or 0.5)
    comp = float(feature_vector.get("completion_rate", 1.0) or 1.0)
    freq = float(feature_vector.get("recent_session_rate", 0.0) or 0.0)
    diff = float(feature_vector.get("difficulty_pref_norm", 0.5) or 0.5)
    exp = float(feature_vector.get("experience_score", 0.35) or 0.35)
    time_budget = float(feature_vector.get("time_budget_norm", 0.2) or 0.2)

    if (m >= 0.65 and c >= 0.62 and q >= 0.62) or (exp >= 0.8 and diff >= 0.55):
        return "C4"
    if m < 0.35 and c < 0.55 and q < 0.55:
        if time_budget <= 0.22 or comp < 0.7 or freq < 0.2:
            return "C2"
        return "C1"
    if comp < 0.72 and (time_budget <= 0.25 or freq < 0.2):
        return "C2"
    return "C3"


def cluster_persona(cluster_id: str) -> str:
    mapping = {
        "C1": "Foundation Starter",
        "C2": "Busy Beginner",
        "C3": "Steady Builder",
        "C4": "Advanced Explorer",
    }
    cid = str(cluster_id or "").strip().upper()
    return mapping.get(cid, "Unknown")

