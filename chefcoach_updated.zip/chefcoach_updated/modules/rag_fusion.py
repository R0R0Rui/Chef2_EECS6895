def rrf_fusion(rank_lists, k=60):
    scores = {}
    for docs in rank_lists:
        for rank, doc in enumerate(docs, start=1):
            key = f"{doc['source']}::{doc['id']}"
            scores.setdefault(key, {"doc": doc, "score": 0})
            scores[key]["score"] += 1.0 / (k + rank)

    fused = [v["doc"] | {"fused_score": v["score"]} for v in scores.values()]
    fused.sort(key=lambda x: x["fused_score"], reverse=True)
    return fused