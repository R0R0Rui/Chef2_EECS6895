"""
Skill Assessor (Module 3)
Lightweight skill assessment via quiz + self-report.
Output: estimated skill_vector + current level.
"""

ASSESSMENT_QUESTIONS = [
    {
        "skill": "knife_safety",
        "question": "How comfortable are you with knife skills?",
        "options": [
            {"text": "I'm nervous holding a knife", "delta": 0.1},
            {"text": "I can do basic chopping", "delta": 0.3},
            {"text": "I can dice, julienne, and mince", "delta": 0.6},
            {"text": "I'm very fast and precise with all cuts", "delta": 0.8}
        ]
    },
    {
        "skill": "heat_control",
        "question": "How well do you manage cooking temperatures?",
        "options": [
            {"text": "I often burn things or undercook", "delta": 0.1},
            {"text": "I can manage medium heat for basic cooking", "delta": 0.3},
            {"text": "I can sear, simmer, and adjust heat confidently", "delta": 0.6},
            {"text": "I intuitively know heat levels for any technique", "delta": 0.8}
        ]
    },
    {
        "skill": "seasoning",
        "question": "How do you approach seasoning food?",
        "options": [
            {"text": "I add salt at the end and hope for the best", "delta": 0.1},
            {"text": "I taste as I go and use salt + pepper", "delta": 0.3},
            {"text": "I layer seasonings and balance flavors intentionally", "delta": 0.6},
            {"text": "I can create complex spice blends and balance all five tastes", "delta": 0.8}
        ]
    },
    {
        "skill": "stir_fry",
        "question": "Have you done stir-frying before?",
        "options": [
            {"text": "Never tried it", "delta": 0.0},
            {"text": "I've done basic vegetable stir-fry", "delta": 0.3},
            {"text": "I can stir-fry with proper technique and timing", "delta": 0.6},
            {"text": "I get great wok hei and cook restaurant-quality stir-fries", "delta": 0.8}
        ]
    },
    {
        "skill": "baking_basics",
        "question": "What's your baking experience?",
        "options": [
            {"text": "I've never baked anything", "delta": 0.0},
            {"text": "I can follow a cookie/cake recipe", "delta": 0.3},
            {"text": "I understand baking science (gluten, leavening)", "delta": 0.6},
            {"text": "I can adjust recipes and troubleshoot baking issues", "delta": 0.8}
        ]
    },
    {
        "skill": "timing",
        "question": "Can you cook multiple things to be ready at the same time?",
        "options": [
            {"text": "No, I cook one thing at a time", "delta": 0.0},
            {"text": "Sometimes, but things often get cold", "delta": 0.2},
            {"text": "I can plan timing for a 2-3 component meal", "delta": 0.5},
            {"text": "I can orchestrate complex multi-course meals", "delta": 0.8}
        ]
    },
    {
        "skill": "sauce",
        "question": "Can you make sauces from scratch?",
        "options": [
            {"text": "I only use jarred/bottled sauces", "delta": 0.0},
            {"text": "I can make a basic pan sauce or vinaigrette", "delta": 0.3},
            {"text": "I can make roux-based sauces and reductions", "delta": 0.6},
            {"text": "I can make emulsions, mother sauces, and complex reductions", "delta": 0.8}
        ]
    },
    {
        "skill": "plating",
        "question": "How do you present your food?",
        "options": [
            {"text": "I just put it on a plate", "delta": 0.1},
            {"text": "I try to make it look nice", "delta": 0.3},
            {"text": "I think about color, height, and composition", "delta": 0.6},
            {"text": "I plate like a professional chef", "delta": 0.8}
        ]
    }
]


def get_assessment_questions():
    """Return the list of assessment questions."""
    return ASSESSMENT_QUESTIONS


def process_assessment(answers):
    """
    Process quiz answers and return initial skill vector.
    
    Args:
        answers: dict of {skill_id: selected_option_index}
    
    Returns:
        dict of {skill_id: float} skill vector
    """
    skill_vector = {}
    for q in ASSESSMENT_QUESTIONS:
        skill = q["skill"]
        idx = answers.get(skill, 0)
        idx = min(idx, len(q["options"]) - 1)
        skill_vector[skill] = q["options"][idx]["delta"]
    return skill_vector
