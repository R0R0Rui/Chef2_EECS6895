# modules/confidence_update.py
from __future__ import annotations
from typing import Dict

def clamp(x: float, lo: float = 0.0, hi: float = 1.0) -> float:
    return max(lo, min(hi, x))

def compute_confidence(feedback: Dict, lesson: Dict) -> float:
    quiz = float(feedback.get("quiz_score", 0.5) or 0.5)  # 0..1
    completed = 1.0 if feedback.get("completed", False) else 0.5

    rating = float(feedback.get("rating", 3) or 3)       # 1..5
    difficulty = float(feedback.get("difficulty", 3) or 3)

    rating_stability = 1.0 - abs(rating - 3.0) / 2.0     # 1 at 3, 0 at 1/5
    diff_stability   = 1.0 - abs(difficulty - 3.0) / 2.0

    lesson_diff = float(lesson.get("difficulty", 2) or 2)  # 1..3
    diff_bonus = 0.05 * (lesson_diff - 1)  # 0, .05, .10

    conf = 0.55 * quiz + 0.25 * completed + 0.10 * rating_stability + 0.10 * diff_stability + diff_bonus
    return clamp(conf)