"""
Feedback Updater (Module 7)
RLHF-Inspired profile update loop.
Collects: rating, difficulty, notes, quiz score, completion status.
Updates: skill_vector, taste_prefs, difficulty target.
Adds: skill_state (xp/level per skill), skill_confidence (0-1), overall level from xp.
"""

import os
import json

from modules.level_system import xp_to_level, compute_overall_level

LEARNING_RATE = float(os.getenv("LEARNING_RATE", "0.15"))


def clamp(x: float, lo: float = 0.0, hi: float = 1.0) -> float:
    return max(lo, min(hi, x))


def compute_confidence(feedback, lesson) -> float:
    """Return a reliability/confidence score in [0,1] for this feedback."""
    # Objective-ish signals
    quiz = float(feedback.get("quiz_score", 0.5) or 0.5)          # 0..1
    completed = 1.0 if feedback.get("completed", True) else 0.5

    # Subjective stability: mid ratings are typically less noisy than extremes
    rating = float(feedback.get("rating", 3) or 3)               # 1..5
    difficulty = float(feedback.get("difficulty", 3) or 3)       # 1..5
    rating_stability = 1.0 - abs(rating - 3.0) / 2.0              # 1 at 3, 0 at 1/5
    diff_stability = 1.0 - abs(difficulty - 3.0) / 2.0

    # Lesson difficulty (1..3) gives a small bonus for harder lessons
    lesson_diff = float(lesson.get("difficulty", 2) or 2)
    diff_bonus = 0.05 * max(0.0, lesson_diff - 1.0)               # 0, .05, .10

    conf = 0.55 * quiz + 0.25 * completed + 0.10 * rating_stability + 0.10 * diff_stability + diff_bonus
    return clamp(conf)


def mastery_to_level(mastery: float) -> int:
    """A simple mastery->level mapping for UI (separate from XP level)."""
    if mastery < 0.33:
        return 1
    if mastery < 0.66:
        return 2
    return 3


def compute_skill_delta(feedback, lesson):
    """
    Compute how much to adjust the target skill based on feedback.
    
    Feedback signals:
    - rating (1-5): overall satisfaction
    - difficulty (1-5): 1=too easy, 3=just right, 5=too hard
    - quiz_score (0.0-1.0): fraction correct
    - completed (bool): did they finish?
    """
    rating = feedback.get("rating", 3)
    difficulty = feedback.get("difficulty", 3)
    quiz_score = feedback.get("quiz_score", 0.5)
    completed = feedback.get("completed", True)

    # Success signal: combination of rating, quiz, and completion
    # High rating + good quiz + completed = strong positive signal
    success_signal = 0.0

    # Rating contribution (normalized to [-1, 1])
    success_signal += (rating - 3) / 2.0 * 0.3

    # Quiz contribution (0 to 1 mapped to [-0.5, 0.5])
    success_signal += (quiz_score - 0.5) * 0.4

    # Completion bonus
    if completed:
        success_signal += 0.2

    # Difficulty adjustment: if too easy, smaller gain; if too hard and failed, no gain
    if difficulty <= 2 and completed:  # Too easy but completed
        success_signal *= 0.7  # Still gain, but less
    elif difficulty >= 4 and not completed:  # Too hard and didn't finish
        success_signal *= 0.3  # Minimal gain

    return success_signal


def compute_taste_deltas(feedback_notes):
    """
    Parse feedback notes to extract taste preference adjustments.
    Simple keyword-based parsing.
    
    Returns dict of {taste: delta} adjustments.
    """
    notes = (feedback_notes or "").lower()
    deltas = {}

    # Keyword mapping
    taste_keywords = {
        "spicy": {"increase": ["more spicy", "more heat", "spicier", "not spicy enough"],
                   "decrease": ["too spicy", "too hot", "less spicy", "tone down heat"]},
        "salty": {"increase": ["more salt", "bland", "underseasoned", "needs salt"],
                  "decrease": ["too salty", "over-salted", "overseasoned"]},
        "sweet": {"increase": ["more sweet", "not sweet enough"],
                  "decrease": ["too sweet", "overly sweet"]},
        "sour": {"increase": ["more acid", "more sour", "needs lemon", "needs vinegar"],
                 "decrease": ["too sour", "too acidic", "too tangy"]},
        "umami": {"increase": ["more depth", "more savory", "more umami"],
                  "decrease": ["too heavy", "too rich"]}
    }

    for taste, keywords in taste_keywords.items():
        for kw in keywords["increase"]:
            if kw in notes:
                deltas[taste] = 0.1
                break
        for kw in keywords["decrease"]:
            if kw in notes:
                deltas[taste] = -0.1
                break

    return deltas


def update_profile(profile, feedback, lesson):
    """
    Apply RLHF-inspired updates to the user profile.
    
    Args:
        profile: current user profile dict
        feedback: feedback dict with rating, difficulty, notes, quiz_score, completed
        lesson: the lesson that was completed
    
    Returns:
        updated profile dict (also modifies in place)
    """
    lr = LEARNING_RATE
    target_skill = lesson["skill"]

    # Ensure containers exist
    profile.setdefault("skill_vector", {})
    profile.setdefault("taste_prefs", {})
    profile.setdefault("completed_lessons", [])
    profile.setdefault("skill_state", {})            # per-skill: {xp, level}
    profile.setdefault("skill_confidence", {})       # per-skill: 0..1

    # 1. Update skill vector (confidence-weighted)
    conf = compute_confidence(feedback, lesson)
    skill_delta = compute_skill_delta(feedback, lesson)

    old_val = float(profile["skill_vector"].get(target_skill, 0.0) or 0.0)
    # Reliability-weighted update: same delta, scaled by confidence
    new_val = clamp(old_val + lr * conf * skill_delta, 0.0, 1.0)
    profile["skill_vector"][target_skill] = round(new_val, 4)

    # Track per-skill confidence as an exponential moving average (EMA)
    old_c = float(profile["skill_confidence"].get(target_skill, 0.5) or 0.5)
    profile["skill_confidence"][target_skill] = round(0.8 * old_c + 0.2 * conf, 4)

    # Track per-skill XP + XP-level (Duolingo-style progression)
    st = profile["skill_state"].setdefault(target_skill, {"xp": 0.0, "level": 1, "mastery_level": 1})
    lesson_diff = float(lesson.get("difficulty", 2) or 2)
    # XP gain scaled by confidence and lesson difficulty
    xp_gain = 60.0 * conf * (0.8 + 0.1 * lesson_diff)
    st["xp"] = float(st.get("xp", 0.0) or 0.0) + xp_gain

    lvl, xp_in_lvl, need = xp_to_level(st["xp"])
    st["level"] = int(lvl)
    st["mastery_level"] = int(mastery_to_level(new_val))

    # 2. Update taste preferences
    taste_deltas = compute_taste_deltas(feedback.get("notes", ""))
    for taste, delta in taste_deltas.items():
        if taste in profile.get("taste_prefs", {}):
            old_pref = profile["taste_prefs"][taste]
            new_pref = max(0.0, min(1.0, old_pref + lr * delta))
            profile["taste_prefs"][taste] = round(new_pref, 4)

    # 3. Track lesson completion
    if lesson["id"] not in profile.get("completed_lessons", []):
        profile.setdefault("completed_lessons", []).append(lesson["id"])

    # 4. Update session count
    profile["total_sessions"] = profile.get("total_sessions", 0) + 1

    # 5. Recalculate overall level (from XP levels)
    profile["current_level"] = compute_overall_level(profile.get("skill_state", {}))

    # Backward-compatible fallback: if skill_state is empty for any reason, derive from avg mastery
    if not profile.get("skill_state"):
        avg_skill = sum(profile["skill_vector"].values()) / max(1, len(profile["skill_vector"]))
        if avg_skill < 0.15:
            profile["current_level"] = 1
        elif avg_skill < 0.3:
            profile["current_level"] = 2
        elif avg_skill < 0.5:
            profile["current_level"] = 3
        elif avg_skill < 0.7:
            profile["current_level"] = 4
        else:
            profile["current_level"] = 5

    return profile


def get_feedback_summary(feedback):
    """Format feedback into a human-readable summary."""
    parts = []
    if "rating" in feedback:
        stars = "⭐" * feedback["rating"]
        parts.append(f"Rating: {stars} ({feedback['rating']}/5)")
    if "difficulty" in feedback:
        diff_labels = {1: "Too Easy", 2: "Easy", 3: "Just Right", 4: "Hard", 5: "Too Hard"}
        parts.append(f"Difficulty: {diff_labels.get(feedback['difficulty'], 'N/A')}")
    if "quiz_score" in feedback:
        parts.append(f"Quiz: {feedback['quiz_score']*100:.0f}%")
    if "notes" in feedback and feedback["notes"]:
        parts.append(f"Notes: \"{feedback['notes']}\"")
    return " | ".join(parts)
