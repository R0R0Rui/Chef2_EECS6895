"""
Curriculum Planner (Module 4)
Uses the skill graph to select the next best lesson.
Strategy: prerequisites + weakest-skill-first + user constraints.
"""

import json
import os
from collections import defaultdict
from typing import Any, Dict, List, Optional, Set, Tuple

SKILLS_PATH = os.path.join(os.path.dirname(__file__), "..", "data", "skills.json")
LESSONS_PATH = os.path.join(os.path.dirname(__file__), "..", "data", "lessons.json")

UNLOCK_THRESHOLD = float(os.getenv("SKILL_UNLOCK_THRESHOLD", "0.4"))


def _load_skills():
    with open(SKILLS_PATH) as f:
        return json.load(f)["skills"]


def _load_lessons():
    with open(LESSONS_PATH) as f:
        return json.load(f)["lessons"]


def _lessons_by_skill() -> Dict[str, List[Dict]]:
    grouped: Dict[str, List[Dict]] = defaultdict(list)
    for lesson in _load_lessons():
        grouped[lesson["skill"]].append(lesson)
    return dict(grouped)


def get_unlocked_skills(skill_vector):
    """
    Return list of skill IDs whose prerequisites are all met.
    A prerequisite is met if skill_vector[prereq] >= UNLOCK_THRESHOLD.
    Skills with no prerequisites are always unlocked.
    """
    skills = _load_skills()
    unlocked = []
    for skill in skills:
        prereqs = skill["prerequisites"]
        threshold = float(skill.get("unlock_threshold", UNLOCK_THRESHOLD))
        if not prereqs:
            unlocked.append(skill["id"])
        elif all(skill_vector.get(p, 0) >= threshold for p in prereqs):
            unlocked.append(skill["id"])
    return unlocked


def get_locked_skills(skill_vector):
    """Return skills that are not yet unlocked."""
    skills = _load_skills()
    unlocked = set(get_unlocked_skills(skill_vector))
    return [s["id"] for s in skills if s["id"] not in unlocked]


def _remaining_lessons_for_skill(skill_id: str, completed: Set[str]) -> List[Dict]:
    by_skill = _lessons_by_skill()
    return [l for l in by_skill.get(skill_id, []) if l["id"] not in completed]


def _all_lessons_completed(completed_lessons: Optional[List[str]]) -> bool:
    completed = set(completed_lessons or [])
    all_ids = {l["id"] for l in _load_lessons()}
    return bool(all_ids) and all_ids.issubset(completed)


def select_next_skill(skill_vector, completed_lessons=None):
    """
    Select the next target skill using weakest-skill-first strategy
    among unlocked skills that still have uncompleted lessons.
    
    Returns: (skill_id, skill_value) or (None, None) if all maxed.
    """
    completed = set(completed_lessons or [])
    unlocked = get_unlocked_skills(skill_vector)
    if not unlocked:
        return None, None

    candidates: List[Tuple[str, float, int]] = []
    for skill_id in unlocked:
        remaining = _remaining_lessons_for_skill(skill_id, completed)
        if not remaining:
            continue
        candidates.append((skill_id, float(skill_vector.get(skill_id, 0.0)), len(remaining)))

    if not candidates:
        return None, None

    # Sort by weakest skill first, then prefer the skill with more remaining lessons.
    candidates.sort(key=lambda x: (x[1], -x[2], x[0]))
    return candidates[0][0], candidates[0][1]


def _lesson_preference_score(lesson: Dict[str, Any], profile: Optional[Dict[str, Any]]) -> float:
    """Soft tie-break score using learner preferences and cluster."""
    if not profile:
        return 0.0

    constraints = profile.get("constraints", {}) or {}
    preferred_cuisines = {
        str(x).strip().lower() for x in (constraints.get("preferred_cuisines", []) or [])
    }
    tags = {
        str(x).strip().lower() for x in (lesson.get("practice_recipe_tags", []) or [])
    }

    score = 0.0
    score += 2.5 * len(preferred_cuisines & tags)

    time_budget = int(constraints.get("time_budget_minutes", 30) or 30)
    if time_budget <= 35 and ({"quick", "simple"} & tags):
        score += 1.0

    cluster_id = str(profile.get("cluster_id", "")).strip().upper()
    if cluster_id in {"C1", "C2"} and ({"simple", "eggs", "soup", "vegetables"} & tags):
        score += 1.2
    elif cluster_id == "C4" and ({"sear", "braise", "spice", "bread", "wok"} & tags):
        score += 1.2

    return score


def select_lesson(skill_vector, completed_lessons=None, profile: Optional[Dict[str, Any]] = None):
    """
    Select the best next lesson based on:
    1. Target skill (weakest unlocked)
    2. Appropriate difficulty level
    3. Not already completed (if possible)
    
    Returns: lesson dict or None
    """
    completed = set(completed_lessons or [])
    if _all_lessons_completed(list(completed)):
        return None

    target_skill, skill_val = select_next_skill(skill_vector, completed_lessons)

    if target_skill is None:
        return None

    # Filter lessons for target skill
    skill_lessons = _lessons_by_skill().get(target_skill, [])
    if not skill_lessons:
        return None

    # Determine appropriate difficulty based on current skill level
    if skill_val < 0.3:
        target_diff = 1
    elif skill_val < 0.6:
        target_diff = 2
    else:
        target_diff = 3

    # Only use uncompleted lessons; if none left, we're done for this skill and caller
    # should move to other skills (handled by select_next_skill).
    uncompleted = [l for l in skill_lessons if l["id"] not in completed]
    if not uncompleted:
        return None
    pool = uncompleted

    # Sort by closeness to target difficulty
    pool.sort(
        key=lambda l: (
            abs(l["difficulty"] - target_diff),
            -_lesson_preference_score(l, profile),
            l.get("id", ""),
        )
    )

    return pool[0]


def get_skill_info(skill_id):
    """Get full info for a specific skill."""
    skills = _load_skills()
    for s in skills:
        if s["id"] == skill_id:
            return s
    return None


def get_all_skills():
    """Return all skills."""
    return _load_skills()


def get_curriculum_state(skill_vector, completed_lessons=None, profile: Optional[Dict[str, Any]] = None):
    """
    Return a comprehensive curriculum state summary.
    Used for display in dashboard and for LLM context.
    """
    unlocked = get_unlocked_skills(skill_vector)
    locked = get_locked_skills(skill_vector)
    next_skill, next_val = select_next_skill(skill_vector, completed_lessons)
    next_lesson = select_lesson(skill_vector, completed_lessons, profile=profile)
    completed_all = _all_lessons_completed(completed_lessons)

    return {
        "unlocked_skills": unlocked,
        "locked_skills": locked,
        "next_target_skill": next_skill,
        "next_target_skill_value": next_val,
        "next_lesson": next_lesson,
        "completed_all_lessons": completed_all,
        "total_skills": len(_load_skills()),
        "skills_above_intermediate": sum(1 for v in skill_vector.values() if v >= 0.4)
    }
