"""rag_retriever.py

RAG Retriever (Module 5)

Implements proposal-aligned RAG:
- Vector DB: ChromaDB (or FAISS alternative if extended)
- Chunking: each recipe → multiple chunks (title/tags, ingredients, steps)
- Retrieval: query chunks, then reassemble FULL recipe packets by recipe_id

Why reassembly matters:
- Retrieval works better with fine-grained chunks.
- Generation works better with a complete recipe packet as grounded context.

Environment variables:
- CHROMA_DB_PATH: persistent directory for Chroma (default: ./chroma_db)
- CHROMA_COLLECTION: collection name (default: recipes)
- EMBEDDING_PROVIDER: sentence_transformer | default (default: sentence_transformer)
- EMBEDDING_MODEL: sentence-transformers model name (default: all-MiniLM-L6-v2)

Fallback behavior:
- If ChromaDB is not available or empty, we fall back to keyword scoring on
  data/sample_recipes.json.
"""

from __future__ import annotations

import json
import os
from typing import Dict, List, Optional, Tuple


CHROMA_DB_PATH = os.getenv("CHROMA_DB_PATH", "./chroma_db")
CHROMA_COLLECTION = os.getenv("CHROMA_COLLECTION", "recipes")
EMBEDDING_PROVIDER = os.getenv("EMBEDDING_PROVIDER", "sentence_transformer").lower()
EMBEDDING_MODEL = os.getenv("EMBEDDING_MODEL", "all-MiniLM-L6-v2")

SAMPLE_RECIPES_PATH = os.path.join(os.path.dirname(__file__), "..", "data", "sample_recipes.json")

_COLLECTION_CACHE = None
_COLLECTION_CACHE_KEY = None


def _safe_float(value, default: float = -1.0) -> float:
    try:
        return float(value)
    except Exception:
        return default


def _safe_int(value, default: int = 0) -> int:
    try:
        return int(value)
    except Exception:
        return default


def _get_collection():
    """Get or create a ChromaDB collection with a deterministic embedding function."""
    global _COLLECTION_CACHE, _COLLECTION_CACHE_KEY
    cache_key = (CHROMA_DB_PATH, CHROMA_COLLECTION, EMBEDDING_PROVIDER, EMBEDDING_MODEL)
    if _COLLECTION_CACHE is not None and _COLLECTION_CACHE_KEY == cache_key:
        return _COLLECTION_CACHE

    try:
        import chromadb
        from chromadb.utils import embedding_functions

        client = chromadb.PersistentClient(path=CHROMA_DB_PATH)

        embedding_fn = None
        if EMBEDDING_PROVIDER == "sentence_transformer":
            # Explicitly specify the model so behavior is reproducible.
            try:
                embedding_fn = embedding_functions.SentenceTransformerEmbeddingFunction(
                    model_name=EMBEDDING_MODEL
                )
            except TypeError:
                # Some Chroma versions accept a device argument.
                embedding_fn = embedding_functions.SentenceTransformerEmbeddingFunction(
                    model_name=EMBEDDING_MODEL, device="cpu"
                )
        elif EMBEDDING_PROVIDER == "default":
            embedding_fn = embedding_functions.DefaultEmbeddingFunction()

        # NOTE: we always pass embedding_function if available to ensure query_texts works.
        if embedding_fn is not None:
            col = client.get_or_create_collection(
                name=CHROMA_COLLECTION,
                metadata={"hnsw:space": "cosine"},
                embedding_function=embedding_fn,
            )
            _COLLECTION_CACHE = col
            _COLLECTION_CACHE_KEY = cache_key
            return col

        col = client.get_or_create_collection(
            name=CHROMA_COLLECTION,
            metadata={"hnsw:space": "cosine"},
        )
        _COLLECTION_CACHE = col
        _COLLECTION_CACHE_KEY = cache_key
        return col

    except Exception as e:
        print(f"ChromaDB not available: {e}")
        return None


def reset_collection() -> bool:
    """Delete and recreate the Chroma collection used by this project.

    This is used by setup_rag.py to avoid stale vectors remaining from
    previous indexing runs (for example, switching from sample data to Food.com).
    """
    global _COLLECTION_CACHE, _COLLECTION_CACHE_KEY

    try:
        import chromadb

        client = chromadb.PersistentClient(path=CHROMA_DB_PATH)
        try:
            client.delete_collection(name=CHROMA_COLLECTION)
        except Exception:
            # It's fine if the collection does not exist yet.
            pass

        _COLLECTION_CACHE = None
        _COLLECTION_CACHE_KEY = None

        # Recreate collection eagerly so downstream indexing fails fast if broken.
        return _get_collection() is not None
    except Exception as e:
        print(f"Could not reset Chroma collection: {e}")
        return False


def index_recipes(recipes: List[Dict]) -> bool:
    """Index a list of recipe dicts into ChromaDB.

    Each recipe is chunked into:
    - title/tags
    - ingredients
    - steps

    All chunks share the same recipe_id and are given deterministic IDs so we
    can reassemble full packets after retrieval.
    """
    collection = _get_collection()
    if collection is None:
        return False

    documents: List[str] = []
    metadatas: List[Dict] = []
    ids: List[str] = []

    for recipe in recipes:
        rid = str(recipe.get("id"))
        title = str(recipe.get("title", "Untitled"))
        raw_rating = recipe.get("rating")
        rating = _safe_float(raw_rating, -1.0) if raw_rating is not None else -1.0
        rating_count = _safe_int(recipe.get("rating_count", 0) or 0, 0)

        tags_list = recipe.get("tags", []) or []
        if isinstance(tags_list, str):
            tags_list = [t.strip() for t in tags_list.split(",") if t.strip()]
        tags = " ".join(tags_list)
        rating_line = ""
        if rating >= 0:
            rating_line = f"\nAvg Rating: {rating:.2f} (n={rating_count})"

        # Chunk 1: Title + tags
        documents.append(f"Title: {title}\nTags: {tags}{rating_line}")
        metadatas.append(
            {
                "recipe_id": rid,
                "chunk_type": "title",
                "title": title,
                "tags": tags,
                "rating": rating,
                "rating_count": rating_count,
            }
        )
        ids.append(f"{rid}::title")

        # Chunk 2: Ingredients
        ingredients = recipe.get("ingredients", []) or []
        if isinstance(ingredients, str):
            ingredients = [x.strip() for x in ingredients.split(",") if x.strip()]
        ingredients_text = "Ingredients:\n- " + "\n- ".join(map(str, ingredients))
        documents.append(ingredients_text)
        metadatas.append(
            {
                "recipe_id": rid,
                "chunk_type": "ingredients",
                "title": title,
                "tags": tags,
                "rating": rating,
                "rating_count": rating_count,
            }
        )
        ids.append(f"{rid}::ingredients")

        # Chunk 3: Steps
        steps = recipe.get("steps", []) or []
        if isinstance(steps, str):
            # crude fallback for dot-separated strings
            steps = [s.strip() for s in steps.split(".") if s.strip()]
        steps_text = "Steps:\n" + "\n".join(f"{i+1}. {s}" for i, s in enumerate(map(str, steps)))
        documents.append(steps_text)
        metadatas.append(
            {
                "recipe_id": rid,
                "chunk_type": "steps",
                "title": title,
                "tags": tags,
                "rating": rating,
                "rating_count": rating_count,
            }
        )
        ids.append(f"{rid}::steps")

    # Upsert in batches
    batch_size = 200
    for i in range(0, len(documents), batch_size):
        j = min(i + batch_size, len(documents))
        collection.upsert(
            documents=documents[i:j],
            metadatas=metadatas[i:j],
            ids=ids[i:j],
        )

    return True


def retrieve_recipe_packets(
    query: str,
    *,
    tags_filter: Optional[List[str]] = None,
    top_k_recipes: int = 3,
    top_k_chunks: int = 18,
) -> List[Dict]:
    """Retrieve and reassemble full recipe packets.

    Returns a list of dict packets:
    {
      "recipe_id": str,
      "title": str,
      "tags": str,
      "chunks": {"title": str, "ingredients": str, "steps": str},
      "matched_chunk_types": ["ingredients", ...]
    }
    """
    collection = _get_collection()

    # Fallback if Chroma missing/empty
    if collection is None:
        return _fallback_retrieve(query, tags_filter=tags_filter, top_k_recipes=top_k_recipes)

    try:
        if collection.count() == 0:
            return _fallback_retrieve(query, tags_filter=tags_filter, top_k_recipes=top_k_recipes)
    except Exception:
        # If count fails for any reason, still try query.
        pass

    # Expand query with tags filter (simple but effective)
    if tags_filter:
        query = query + " " + " ".join(tags_filter)

    try:
        results = collection.query(
            query_texts=[query],
            n_results=min(max(1, top_k_chunks), 50),
            include=["documents", "metadatas", "distances"],
        )
    except Exception:
        return _fallback_retrieve(query, tags_filter=tags_filter, top_k_recipes=top_k_recipes)

    docs = (results.get("documents") or [[]])[0]
    metas = (results.get("metadatas") or [[]])[0]
    dists = (results.get("distances") or [[]])[0]

    if not docs or not metas:
        return _fallback_retrieve(query, tags_filter=tags_filter, top_k_recipes=top_k_recipes)

    # Group matches by recipe_id
    by_recipe: Dict[str, Dict] = {}
    for meta in metas:
        rid = str(meta.get("recipe_id"))
        by_recipe.setdefault(
            rid,
            {
                "matched_chunk_types": set(),
                "title": meta.get("title", ""),
                "tags": meta.get("tags", ""),
                "rating": meta.get("rating", -1.0),
                "rating_count": _safe_int(meta.get("rating_count", 0) or 0, 0),
            },
        )
        by_recipe[rid]["matched_chunk_types"].add(meta.get("chunk_type", ""))

    # Take top recipe IDs in order of appearance in results (fast heuristic)
    recipe_ids: List[str] = []
    for meta in metas:
        rid = str(meta.get("recipe_id"))
        if rid not in recipe_ids:
            recipe_ids.append(rid)
        if len(recipe_ids) >= top_k_recipes:
            break

    packets: List[Dict] = []

    for rid in recipe_ids:
        # Reassemble FULL packet by deterministic IDs
        chunk_ids = [f"{rid}::title", f"{rid}::ingredients", f"{rid}::steps"]
        chunks = {"title": "", "ingredients": "", "steps": ""}

        try:
            got = collection.get(ids=chunk_ids, include=["documents", "metadatas"])
            got_docs = got.get("documents", [])
            got_meta = got.get("metadatas", [])
            for d, m in zip(got_docs, got_meta):
                ctype = m.get("chunk_type")
                if ctype in chunks:
                    chunks[ctype] = d

            title = ""
            tags = ""
            rating = -1.0
            rating_count = 0
            for m in got_meta:
                if m.get("chunk_type") == "title":
                    title = m.get("title", title)
                    tags = m.get("tags", tags)
                    rating = _safe_float(m.get("rating", rating), rating)
                    rating_count = _safe_int(m.get("rating_count", 0) or 0, 0)
                    break

        except Exception:
            # If get fails, fall back to whatever was matched
            title = by_recipe.get(rid, {}).get("title", "")
            tags = by_recipe.get(rid, {}).get("tags", "")
            rating = _safe_float(by_recipe.get(rid, {}).get("rating", -1.0), -1.0)
            rating_count = _safe_int(by_recipe.get(rid, {}).get("rating_count", 0) or 0, 0)

        packets.append(
            {
                "recipe_id": rid,
                "title": title,
                "tags": tags,
                "rating": rating if rating >= 0 else None,
                "rating_count": rating_count,
                "chunks": chunks,
                "matched_chunk_types": sorted(list(by_recipe.get(rid, {}).get("matched_chunk_types", set()))),
            }
        )

    return packets


def format_recipe_context(packets: List[Dict], *, max_recipes: int = 3) -> str:
    """Format retrieved recipe packets into a single context string for the LLM."""
    parts: List[str] = []
    for i, pkt in enumerate(packets[:max_recipes]):
        header = f"--- Recipe Packet {i+1} (recipe_id={pkt['recipe_id']}) ---"
        title_line = pkt.get("chunks", {}).get("title") or f"Title: {pkt.get('title', '')}\nTags: {pkt.get('tags', '')}"
        ingredients = pkt.get("chunks", {}).get("ingredients", "")
        steps = pkt.get("chunks", {}).get("steps", "")
        matched = ", ".join(pkt.get("matched_chunk_types", [])) or "(unknown)"
        rating = pkt.get("rating")
        rating_count = _safe_int(pkt.get("rating_count", 0) or 0, 0)
        rating_line = f"Avg Rating: {rating:.2f} (n={rating_count})" if rating is not None else "Avg Rating: N/A"
        parts.append("\n".join([header, f"Matched on: {matched}", rating_line, title_line, ingredients, steps]).strip())
    return "\n\n".join(parts).strip()


# ---------------------------- Fallback retrieval ----------------------------

def _fallback_retrieve(query: str, *, tags_filter: Optional[List[str]], top_k_recipes: int) -> List[Dict]:
    """Fallback: keyword scoring over the small built-in sample set."""
    try:
        with open(SAMPLE_RECIPES_PATH, "r", encoding="utf-8") as f:
            recipes = json.load(f)
    except Exception:
        return []

    query_lower = query.lower()
    tags_lower = [t.lower() for t in (tags_filter or [])]

    scored = []
    for r in recipes:
        title = (r.get("title") or "").lower()
        tags = " ".join(r.get("tags", []) or []).lower()
        blob = f"{title} {tags}"
        score = 0

        for w in query_lower.split():
            if w in blob:
                score += 2
        for t in tags_lower:
            if t in blob:
                score += 3

        scored.append((score, r))

    scored.sort(key=lambda x: x[0], reverse=True)

    out: List[Dict] = []
    for _, r in scored[:top_k_recipes]:
        rid = str(r.get("id"))
        title = r.get("title", "")
        tags = " ".join(r.get("tags", []) or [])
        ingredients = r.get("ingredients", []) or []
        steps = r.get("steps", []) or []

        out.append(
            {
                "recipe_id": rid,
                "title": title,
                "tags": tags,
                "rating": r.get("rating"),
                "rating_count": _safe_int(r.get("rating_count", 0) or 0, 0),
                "chunks": {
                    "title": f"Title: {title}\nTags: {tags}",
                    "ingredients": "Ingredients:\n- " + "\n- ".join(map(str, ingredients)),
                    "steps": "Steps:\n" + "\n".join(f"{i+1}. {s}" for i, s in enumerate(map(str, steps))),
                },
                "matched_chunk_types": ["fallback"],
            }
        )

    return out

# Backwards-compatible API (used by earlier code)

def retrieve_recipes(query: str, tags_filter: Optional[List[str]] = None, n_results: int = 5):
    """Compatibility wrapper.

    Older code calls retrieve_recipes(..., n_results=k). In the new design,
    we return top_k_recipes=k recipe packets.
    """
    return retrieve_recipe_packets(
        query,
        tags_filter=tags_filter,
        top_k_recipes=n_results,
        top_k_chunks=max(12, n_results * 6),
    )


# ---------------------------- Evidence retrieval (for fusion) ----------------------------

def retrieve_recipe_evidence(
    query: str,
    *,
    tags_filter: Optional[List[str]] = None,
    top_k_chunks: int = 12,
) -> List[Dict]:
    """Return ranked recipe *chunks* as evidence docs for RAG fusion.

    Output format is standardized so it can be merged with other sources (e.g., technique snippets)
    using Reciprocal Rank Fusion (RRF).

    Each item:
      {
        "source": "recipe",
        "id": "<recipe_id>::<chunk_type>",
        "title": "<recipe title>",
        "text": "<chunk text>",
        "score": float,   # higher is better
        "meta": {...}
      }
    """
    collection = _get_collection()

    # If Chroma missing/empty, fall back to keyword scoring over sample recipes.
    if collection is None:
        return _fallback_retrieve_evidence(query, tags_filter=tags_filter, top_k_chunks=top_k_chunks)

    try:
        if collection.count() == 0:
            return _fallback_retrieve_evidence(query, tags_filter=tags_filter, top_k_chunks=top_k_chunks)
    except Exception:
        pass

    q = query
    if tags_filter:
        q = q + " " + " ".join(tags_filter)

    try:
        results = collection.query(
            query_texts=[q],
            n_results=min(max(1, top_k_chunks), 50),
            include=["documents", "metadatas", "distances"],
        )
    except Exception:
        return _fallback_retrieve_evidence(query, tags_filter=tags_filter, top_k_chunks=top_k_chunks)

    docs = (results.get("documents") or [[]])[0]
    metas = (results.get("metadatas") or [[]])[0]
    dists = (results.get("distances") or [[]])[0]

    out: List[Dict] = []
    for i, (d, m) in enumerate(zip(docs, metas)):
        dist = None
        if i < len(dists):
            dist = dists[i]
        # With cosine space, Chroma distance is typically (1 - cosine_similarity).
        # Convert to a "higher is better" score.
        score = 0.0
        try:
            if dist is not None:
                score = 1.0 - float(dist)
        except Exception:
            score = 0.0

        rid = str(m.get("recipe_id", ""))
        ctype = str(m.get("chunk_type", "chunk"))
        title = str(m.get("title", ""))

        out.append(
            {
                "source": "recipe",
                "id": f"{rid}::{ctype}" if rid else f"unknown::{ctype}",
                "title": title,
                "text": str(d),
                "score": float(score),
                "meta": {
                    "recipe_id": rid,
                    "chunk_type": ctype,
                    "tags": m.get("tags", ""),
                    "rating": m.get("rating", -1.0),
                    "rating_count": _safe_int(m.get("rating_count", 0) or 0, 0),
                },
            }
        )

    # Already ranked by Chroma order; keep stable and trim.
    return out[:top_k_chunks]


def _fallback_retrieve_evidence(
    query: str,
    *,
    tags_filter: Optional[List[str]],
    top_k_chunks: int,
) -> List[Dict]:
    """Fallback evidence: create pseudo-chunks from sample recipes and keyword-score them."""
    try:
        with open(SAMPLE_RECIPES_PATH, "r", encoding="utf-8") as f:
            recipes = json.load(f)
    except Exception:
        return []

    q = (query or "").lower()
    tags_lower = [t.lower() for t in (tags_filter or [])]

    scored: List[Tuple[int, Dict]] = []
    for r in recipes:
        rid = str(r.get("id"))
        title = r.get("title", "")
        tags = " ".join(r.get("tags", []) or [])
        ingredients = r.get("ingredients", []) or []
        steps = r.get("steps", []) or []

        # Build three pseudo-chunks like the Chroma indexer.
        chunks = [
            ("title", f"Title: {title}\nTags: {tags}"),
            ("ingredients", "Ingredients:\n- " + "\n- ".join(map(str, ingredients))),
            ("steps", "Steps:\n" + "\n".join(f"{i+1}. {s}" for i, s in enumerate(map(str, steps)))),
        ]

        for ctype, text in chunks:
            blob = f"{title} {tags} {text}".lower()
            score = 0
            for w in q.split():
                if w and w in blob:
                    score += 2
            for t in tags_lower:
                if t and t in blob:
                    score += 3

            scored.append(
                (
                    score,
                    {
                        "source": "recipe",
                        "id": f"{rid}::{ctype}",
                        "title": title,
                        "text": text,
                        "score": float(score),
                        "meta": {"recipe_id": rid, "chunk_type": ctype, "tags": tags, "rating": r.get("rating"), "rating_count": _safe_int(r.get("rating_count", 0) or 0, 0)},
                    },
                )
            )

    scored.sort(key=lambda x: x[0], reverse=True)
    return [d for _, d in scored[:top_k_chunks]]
