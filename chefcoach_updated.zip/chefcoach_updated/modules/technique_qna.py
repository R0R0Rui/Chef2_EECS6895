"""technique_qna.py

Optional Tier-2 helper:
Lightweight local retrieval for cooking technique Q&A snippets.
Used to enrich "I'm stuck" responses with short why/how explanations.
"""

from __future__ import annotations

import json
import os
import re
from typing import Dict, List, Tuple, Optional


QNA_PATH = os.path.join(os.path.dirname(__file__), "..", "data", "technique_qna.json")
STOPWORDS = {
    "the", "and", "for", "with", "that", "this", "from", "your", "you",
    "what", "when", "where", "which", "why", "how", "can", "should",
    "are", "was", "were", "into", "about", "have", "has", "had", "not",
    "too", "very", "just", "then", "than", "out", "its", "it's", "my",
    "difference", "between", "mean", "means",
}

ALIASES = {
    "plate": "plating",
    "plated": "plating",
    "plates": "plating",
    "fry": "stir_fry",
    "fried": "stir_fry",
    "frying": "stir_fry",
    "stirfry": "stir_fry",
    "stir-fry": "stir_fry",
    "sauces": "sauce",
    "bake": "baking",
    "bakes": "baking",
}


def _tokenize(text: str) -> List[str]:
    raw = re.findall(r"[a-zA-Z_]+", text.lower())
    out = []
    for t in raw:
        if len(t) < 3 or t in STOPWORDS:
            continue

        tok = ALIASES.get(t, t)
        out.append(tok)

        # Lightweight stemming to improve match robustness.
        if tok.endswith("ing") and len(tok) > 5:
            out.append(tok[:-3])
        elif tok.endswith("ed") and len(tok) > 4:
            out.append(tok[:-2])
        elif tok.endswith("s") and len(tok) > 4:
            out.append(tok[:-1])

    return out


def _load_qna() -> List[Dict]:
    if not os.path.exists(QNA_PATH):
        return []
    try:
        with open(QNA_PATH, "r", encoding="utf-8") as f:
            rows = json.load(f)
        return rows if isinstance(rows, list) else []
    except Exception:
        return []


def _score_row(query_tokens: set, row: Dict) -> int:
    """Return an integer relevance score for a technique snippet row."""
    q_tokens = set(_tokenize(row.get("question", "")))
    a_tokens = set(_tokenize(row.get("answer", "")))
    tags_tokens = set(_tokenize(" ".join(row.get("tags", []) or [])))

    return (
        3 * len(query_tokens & q_tokens)
        + 2 * len(query_tokens & tags_tokens)
        + 1 * len(query_tokens & a_tokens)
    )


def _row_id(row: Dict, idx: int) -> str:
    """Stable-ish id for a row, used for evidence fusion."""
    q = (row.get("question", "") or "").strip().lower()
    if q:
        # Compact slug based on tokens.
        toks = _tokenize(q)
        slug = "_".join(toks[:8]) if toks else "q"
        return f"tech::{slug}"
    return f"tech::row{idx}"


def retrieve_technique_snippets(query: str, *, top_k: int = 3) -> List[Dict]:
    """Weighted keyword score over local Q&A snippets.

    Scoring emphasizes question/tags so hits are more on-topic:
    - overlap with question tokens: weight 3
    - overlap with tags tokens: weight 2
    - overlap with answer tokens: weight 1
    """
    rows = _load_qna()
    if not rows:
        return []

    tokens = set(_tokenize(query))
    if not tokens:
        return []

    scored = []
    for row in rows:
        score = _score_row(tokens, row)
        if score >= 2:
            scored.append((score, row))

    scored.sort(key=lambda x: x[0], reverse=True)
    return [x[1] for x in scored[: max(1, top_k)]]


def retrieve_technique_evidence(
    query: str,
    *,
    tags_filter: Optional[List[str]] = None,
    top_k: int = 6,
) -> List[Dict]:
    """Return ranked technique snippets as standardized evidence docs for RAG fusion.

    Output format matches `retrieve_recipe_evidence` so it can be merged using RRF.

    Each item:
      {
        "source": "technique",
        "id": "tech::<slug>",
        "title": "<question>",
        "text": "Q: ...\nA: ...",
        "score": float,   # higher is better
        "meta": {"tags": [...]} 
      }
    """
    rows = _load_qna()
    if not rows:
        return []

    q = query or ""
    if tags_filter:
        q = q + " " + " ".join(tags_filter)

    tokens = set(_tokenize(q))
    if not tokens:
        return []

    scored: List[Tuple[int, int, Dict]] = []
    for idx, row in enumerate(rows):
        s = _score_row(tokens, row)
        if s >= 2:
            scored.append((s, idx, row))

    scored.sort(key=lambda x: x[0], reverse=True)

    out: List[Dict] = []
    for s, idx, row in scored[: max(1, top_k)]:
        question = (row.get("question", "") or "").strip()
        answer = (row.get("answer", "") or "").strip()
        tags = row.get("tags", []) or []
        text = ""
        if question and answer:
            text = f"Q: {question}\nA: {answer}"
        elif answer:
            text = answer
        else:
            text = question

        out.append(
            {
                "source": "technique",
                "id": _row_id(row, idx),
                "title": question or "Technique snippet",
                "text": text,
                "score": float(s),
                "meta": {"tags": tags},
            }
        )

    return out


def format_technique_snippets(snippets: List[Dict]) -> str:
    if not snippets:
        return ""
    parts = []
    for i, s in enumerate(snippets, start=1):
        q = s.get("question", "").strip()
        a = s.get("answer", "").strip()
        if q and a:
            parts.append(f"{i}) Q: {q}\nA: {a}")
    return "\n\n".join(parts).strip()
