"""llm_client.py

Unified LLM interface for ChefCoach.

Supported providers:
- gemini: Google Gemini via REST (Generative Language API)
- openai: OpenAI / OpenAI-compatible chat completions (via openai-python)
- mock: offline deterministic responses for testing

Environment variables:
- LLM_PROVIDER: gemini | openai | mock (default: gemini)

Gemini:
- GEMINI_API_KEY: your API key
- GEMINI_MODEL: e.g., gemini-1.5-flash (default)

OpenAI-compatible:
- OPENAI_API_KEY
- OPENAI_API_BASE: https://api.openai.com/v1 (or other compatible base)
- MODEL_NAME: model id (default: gpt-4o-mini)

Notes:
- This module is intentionally lightweight (no external SDK required for Gemini).
"""

from __future__ import annotations

import base64
import json
import os
import re
import time
from dataclasses import dataclass
from typing import Any, Dict, List, Optional

import requests

_HTTP = requests.Session()


@dataclass
class ChatMessage:
    role: str  # "system" | "user" | "assistant"
    content: str


class LLMError(RuntimeError):
    pass


def _safe_excerpt(text: str, limit: int = 300) -> str:
    text = (text or "").strip().replace("\n", " ")
    return text[:limit] + ("..." if len(text) > limit else "")


def get_provider() -> str:
    return os.getenv("LLM_PROVIDER", "gemini").strip().lower()


def get_provider_config_error(provider: Optional[str] = None) -> Optional[str]:
    """Return a user-facing config error string for the selected provider."""
    selected = (provider or get_provider()).strip().lower()

    if selected == "gemini":
        if not os.getenv("GEMINI_API_KEY", "").strip():
            return (
                "LLM_PROVIDER=gemini but GEMINI_API_KEY is missing. "
                "Set GEMINI_API_KEY in your .env file."
            )
        return None

    if selected == "openai":
        if not os.getenv("OPENAI_API_KEY", "").strip():
            return (
                "LLM_PROVIDER=openai but OPENAI_API_KEY is missing. "
                "Set OPENAI_API_KEY in your .env file."
            )
        return None

    if selected == "mock":
        return None

    return f"Unsupported LLM_PROVIDER: {selected}"


def chat(
    messages: List[ChatMessage],
    *,
    temperature: float = 0.6,
    max_tokens: int = 2048,
    expect_json: bool = False,
) -> str:
    """Send a chat request to the configured LLM provider and return text."""
    provider = get_provider()
    cfg_error = get_provider_config_error(provider)
    if cfg_error:
        raise LLMError(cfg_error)

    if provider == "gemini":
        return _chat_gemini(messages, temperature=temperature, max_tokens=max_tokens)
    if provider == "openai":
        return _chat_openai(messages, temperature=temperature, max_tokens=max_tokens, expect_json=expect_json)
    if provider == "mock":
        return _chat_mock(messages, expect_json=expect_json)
    raise LLMError(f"Unsupported LLM_PROVIDER: {provider}")


def analyze_image(
    image_bytes: bytes,
    *,
    mime_type: str = "image/jpeg",
    prompt: str = "",
    max_tokens: int = 800,
) -> str:
    """Identify an ingredient or kitchen tool from an uploaded image.

    This MVP feature is intentionally scoped to Gemini because the current app
    already uses the Gemini REST API and does not maintain a separate vision
    backend for local models.
    """
    provider = get_provider()
    cfg_error = get_provider_config_error(provider)
    if cfg_error:
        raise LLMError(cfg_error)
    if provider != "gemini":
        raise LLMError("Image identification is available only when LLM_PROVIDER=gemini.")
    return _analyze_image_gemini(
        image_bytes=image_bytes,
        mime_type=mime_type,
        prompt=prompt,
        max_tokens=max_tokens,
    )


# ---------------------------- Gemini (REST) ----------------------------

def _chat_gemini(messages: List[ChatMessage], *, temperature: float, max_tokens: int) -> str:
    api_key = os.getenv("GEMINI_API_KEY", "").strip()
    if not api_key:
        raise LLMError("GEMINI_API_KEY is not set. Put it in your .env file.")

    model = os.getenv("GEMINI_MODEL", "gemini-1.5-flash").strip()

    system_text: Optional[str] = None
    contents: List[Dict[str, Any]] = []

    for m in messages:
        if m.role == "system":
            # Gemini uses a separate systemInstruction field
            system_text = m.content
            continue

        role = "user" if m.role == "user" else "model"
        contents.append({"role": role, "parts": [{"text": m.content}]})

    payload: Dict[str, Any] = {
        "contents": contents,
        "generationConfig": {
            "temperature": temperature,
            "maxOutputTokens": max_tokens,
        },
    }
    if system_text:
        payload["systemInstruction"] = {"parts": [{"text": system_text}]}

    # Generative Language API endpoint
    url = f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent"

    def _retry_after_seconds(detail: str) -> Optional[float]:
        m = re.search(r"retry in\s+([0-9]+(?:\.[0-9]+)?)s", detail, flags=re.IGNORECASE)
        if not m:
            return None
        try:
            return float(m.group(1))
        except Exception:
            return None

    def _request_once(req_payload: Dict[str, Any]) -> Dict[str, Any]:
        # Retry transient issues so consecutive UI clicks are less brittle.
        for attempt in range(3):
            try:
                resp = _HTTP.post(url, params={"key": api_key}, json=req_payload, timeout=45)
            except requests.RequestException as e:
                if attempt < 2:
                    time.sleep(1.2 * (attempt + 1))
                    continue
                raise LLMError(f"Gemini network request failed ({type(e).__name__}).")

            if resp.status_code >= 400:
                detail = ""
                try:
                    detail = str(resp.json().get("error", {}).get("message", "")).strip()
                except Exception:
                    detail = _safe_excerpt(resp.text or "", limit=320)

                # Retry on rate limits and transient server failures.
                if resp.status_code in (429, 500, 503) and attempt < 2:
                    wait_s = _retry_after_seconds(detail)
                    if wait_s is None:
                        wait_s = 2.0 * (attempt + 1)
                    time.sleep(min(max(wait_s, 1.0), 20.0))
                    continue

                if resp.status_code == 401:
                    raise LLMError("Gemini auth failed (401). Check GEMINI_API_KEY.")
                if resp.status_code == 403:
                    raise LLMError("Gemini access denied (403). Check project permissions/billing.")
                if resp.status_code == 429:
                    raise LLMError(f"Gemini quota/rate limit exceeded (429). {detail}")
                raise LLMError(f"Gemini API error ({resp.status_code}). {detail}")

            try:
                return resp.json()
            except Exception:
                if attempt < 2:
                    time.sleep(1.0)
                    continue
                raise LLMError("Gemini returned non-JSON response.")

        raise LLMError("Gemini request failed after retries.")

    def _extract_text(data: Dict[str, Any]) -> str:
        candidates = data.get("candidates", [])
        if not candidates:
            raise LLMError(f"Gemini returned no candidates: {data}")

        first = candidates[0]
        parts = first.get("content", {}).get("parts", []) or []
        text = "".join((p.get("text", "") if isinstance(p, dict) else "") for p in parts).strip()
        if text:
            return text

        finish_reason = str(first.get("finishReason", "")).strip().upper()
        if finish_reason == "MAX_TOKENS":
            raise LLMError("Gemini returned no visible text before hitting MAX_TOKENS.")
        raise LLMError(f"Gemini candidate has no text parts (finishReason={finish_reason or 'unknown'}).")

    data = _request_once(payload)
    try:
        return _extract_text(data)
    except LLMError as first_err:
        # Some Gemini responses can consume budget without returning visible text.
        # Retry once with a larger output budget before failing.
        if "MAX_TOKENS" not in str(first_err).upper():
            raise

        retry_payload = dict(payload)
        retry_cfg = dict(payload.get("generationConfig", {}))
        retry_cfg["maxOutputTokens"] = min(3072, max(1024, int(max_tokens) * 2))
        retry_payload["generationConfig"] = retry_cfg

        retry_data = _request_once(retry_payload)
        return _extract_text(retry_data)


def _analyze_image_gemini(
    *,
    image_bytes: bytes,
    mime_type: str,
    prompt: str,
    max_tokens: int,
) -> str:
    api_key = os.getenv("GEMINI_API_KEY", "").strip()
    if not api_key:
        raise LLMError("GEMINI_API_KEY is not set. Put it in your .env file.")

    model = (
        os.getenv("GEMINI_VISION_MODEL", "").strip()
        or os.getenv("GEMINI_MODEL", "").strip()
        or "gemini-2.5-flash"
    )
    resolved_mime = (mime_type or "image/jpeg").strip().lower()
    if not resolved_mime.startswith("image/"):
        resolved_mime = "image/jpeg"

    if not image_bytes:
        raise LLMError("Uploaded image is empty.")

    image_b64 = base64.b64encode(image_bytes).decode("utf-8")
    user_note = prompt.strip()
    instruction = (
        "You are helping a home cook identify an unknown ingredient or kitchen tool from a photo. "
        "Respond in concise markdown with these exact headings: "
        "### Best Guess, ### Why, ### Cooking Use, ### Safety or Handling. "
        "If uncertain, clearly say so and provide up to two plausible options."
    )
    if user_note:
        instruction += f"\n\nUser note: {user_note}"

    payload = {
        "contents": [
            {
                "role": "user",
                "parts": [
                    {"text": instruction},
                    {
                        "inline_data": {
                            "mime_type": resolved_mime,
                            "data": image_b64,
                        }
                    },
                ],
            }
        ],
        "generationConfig": {
            "temperature": 0.2,
            "maxOutputTokens": max_tokens,
        },
    }

    url = f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent"

    for attempt in range(3):
        try:
            resp = _HTTP.post(url, params={"key": api_key}, json=payload, timeout=60)
        except requests.RequestException as e:
            if attempt < 2:
                time.sleep(1.2 * (attempt + 1))
                continue
            raise LLMError(f"Gemini image request failed ({type(e).__name__}).")

        if resp.status_code >= 400:
            detail = ""
            try:
                detail = str(resp.json().get("error", {}).get("message", "")).strip()
            except Exception:
                detail = _safe_excerpt(resp.text or "", limit=320)

            if resp.status_code in (429, 500, 503) and attempt < 2:
                time.sleep(2.0 * (attempt + 1))
                continue
            if resp.status_code == 400 and "image" in detail.lower():
                raise LLMError(
                    "The configured Gemini model may not support image input. "
                    "Set GEMINI_VISION_MODEL=gemini-2.5-flash and try again."
                )
            raise LLMError(f"Gemini image API error ({resp.status_code}). {detail}")

        try:
            data = resp.json()
        except Exception:
            if attempt < 2:
                time.sleep(1.0)
                continue
            raise LLMError("Gemini returned non-JSON response for image analysis.")

        candidates = data.get("candidates", [])
        if not candidates:
            raise LLMError(f"Gemini returned no candidates for image analysis: {data}")
        parts = candidates[0].get("content", {}).get("parts", []) or []
        text = "".join((p.get("text", "") if isinstance(p, dict) else "") for p in parts).strip()
        if text:
            return text

        finish_reason = str(candidates[0].get("finishReason", "")).strip().upper()
        raise LLMError(
            f"Gemini image response had no text output (finishReason={finish_reason or 'unknown'})."
        )

    raise LLMError("Gemini image analysis failed after retries.")


# ---------------------------- OpenAI compatible ----------------------------

def _chat_openai(
    messages: List[ChatMessage],
    *,
    temperature: float,
    max_tokens: int,
    expect_json: bool = False,
) -> str:
    api_key = os.getenv("OPENAI_API_KEY", "").strip()
    if not api_key:
        raise LLMError("OPENAI_API_KEY is not set. Put it in your .env file.")

    try:
        from openai import OpenAI
    except Exception as e:
        raise LLMError(
            "openai package not installed. Install it or set LLM_PROVIDER=gemini. "
            f"Original error: {e}"
        )

    client = OpenAI(
        api_key=api_key,
        base_url=os.getenv("OPENAI_API_BASE", "https://api.openai.com/v1"),
    )
    model = os.getenv("MODEL_NAME", "gpt-4o-mini")

    req = {
        "model": model,
        "messages": [{"role": m.role, "content": m.content} for m in messages],
        "temperature": temperature,
        "max_tokens": max_tokens,
    }

    if expect_json:
        # Many OpenAI-compatible backends (including recent Ollama builds)
        # support this and return stricter JSON outputs.
        req["response_format"] = {"type": "json_object"}

    try:
        resp = client.chat.completions.create(**req)
    except Exception as e:
        if not expect_json:
            raise LLMError(f"OpenAI-compatible API error: {e}")

        # Fallback for backends that do not support response_format.
        req.pop("response_format", None)
        try:
            resp = client.chat.completions.create(**req)
        except Exception as e2:
            raise LLMError(f"OpenAI-compatible API error: {e2}")

    return (resp.choices[0].message.content or "").strip()


# ---------------------------- Mock (offline) ----------------------------

def _chat_mock(messages: List[ChatMessage], *, expect_json: bool = False) -> str:
    # Deterministic "fake" output useful for offline testing and CI.
    user_text = "\n".join(m.content for m in messages if m.role == "user")
    if expect_json:
        return json.dumps(
            {
                "output_a_scores": {"personalization": 2, "difficulty": 2, "clarity": 3, "safety": 2, "teaching": 2},
                "output_b_scores": {"personalization": 4, "difficulty": 4, "clarity": 4, "safety": 4, "teaching": 4},
                "winner": "B",
                "reasoning": "Mock judge: output B looks more personalized and instructional.",
            },
            indent=2,
        )

    # Coaching style skeleton
    return (
        "## 🎯 Lesson Objective\n"
        "Practice one core technique with a simple dish.\n\n"
        "## 📋 Mise en Place (What to Prepare)\n"
        "1. Read the recipe once.\n2. Gather ingredients and tools.\n\n"
        "## 👨‍🍳 Step-by-Step Coaching\n"
        "1. Follow the recipe steps carefully.\n"
        "2. Pause and observe texture/color changes.\n"
        "3. Taste and adjust seasoning gradually.\n\n"
        "## ⚠️ Common Mistakes to Avoid\n"
        "- Rushing preheat\n- Overcrowding the pan\n- Not tasting as you go\n\n"
        "## 🧠 Reflection Questions\n"
        "1. What changed when you adjusted heat?\n"
        "2. What would you do differently next time?\n\n"
        "## 🏆 What You Learned\n"
        "You practiced the target skill and built confidence.\n"
    )


def extract_first_json(text: str) -> Dict[str, Any]:
    """Extract the first JSON object from a model response."""
    # Try direct parse
    try:
        return json.loads(text)
    except Exception:
        pass

    # Remove code fences
    cleaned = re.sub(r"```(?:json)?", "", text, flags=re.IGNORECASE).replace("```", "")

    # Find first {...}
    match = re.search(r"\{.*\}", cleaned, flags=re.DOTALL)
    if not match:
        raise ValueError("No JSON object found in response")
    return json.loads(match.group(0))
