"""coach_generator.py

Coach Generator (Module 6)

Generates a Duolingo-style cooking lesson (micro-lesson + practice + coaching)
from:
  - learner profile (skill_vector, preferences, constraints)
  - curriculum selection (lesson template)
  - retrieved recipe context (RAG packets)
  - optional previous-session feedback

LLM backend is configurable via environment variables (Gemini or OpenAI-compatible).
See modules/llm_client.py and .env.example.
"""

from __future__ import annotations

from typing import Optional, Dict, Any

from .llm_client import ChatMessage, chat
from .rag_retriever import retrieve_recipes, format_recipe_context, retrieve_recipe_evidence
from .technique_qna import retrieve_technique_snippets, format_technique_snippets, retrieve_technique_evidence
from .rag_fusion import rrf_fusion

# === Fused evidence helpers ===

def _build_fusion_query(profile: Dict[str, Any], lesson: Dict[str, Any], session_context: Optional[Dict[str, Any]] = None) -> str:
    """Build a retrieval query that works for both recipe chunks and technique snippets."""
    parts = []
    title = str(lesson.get("title", "")).strip()
    skill = str(lesson.get("skill", "")).strip()
    objective = str(lesson.get("objective", "")).strip()
    technique_focus = str(lesson.get("technique_focus", "")).strip()

    if title:
        parts.append(title)
    if skill:
        parts.append(skill)
    if technique_focus:
        parts.append(technique_focus)
    if objective:
        parts.append(objective)

    constraints = profile.get("constraints", {}) or {}
    dietary = constraints.get("dietary") or []
    if dietary:
        parts.append(" ".join(map(str, dietary)))

    if session_context:
        goal = str(session_context.get("goal", "") or "").strip()
        if goal:
            parts.append(goal)
        ingredients = session_context.get("ingredients", []) or []
        if isinstance(ingredients, str):
            ingredients = [x.strip() for x in ingredients.split(",") if x.strip()]
        if ingredients:
            parts.append("ingredients: " + ", ".join(map(str, ingredients[:10])))

    return " | ".join([p for p in parts if p])


def _format_evidence_context(docs: list[dict], *, max_docs: int = 8, max_chars: int = 9000) -> str:
    """Format standardized evidence docs into a compact prompt block."""
    lines: list[str] = []
    for i, d in enumerate(docs[:max_docs], start=1):
        src = str(d.get("source", "source"))
        title = str(d.get("title", "")).strip() or str(d.get("id", ""))
        text = str(d.get("text", "")).strip()
        meta = d.get("meta", {}) or {}
        extra = ""
        if src == "recipe":
            ctype = meta.get("chunk_type")
            if ctype:
                extra = f" ({ctype})"
        lines.append(f"[{src}-{i}] {title}{extra}\n{text}")

    out = "\n\n".join(lines).strip()
    if len(out) > max_chars:
        out = out[:max_chars] + "\n\n[Evidence truncated for token budget.]"
    return out


def _retrieve_fused_evidence(profile: Dict[str, Any], lesson: Dict[str, Any], session_context: Optional[Dict[str, Any]] = None) -> tuple[str, list[dict]]:
    """Retrieve recipe + technique evidence and fuse with RRF.

    Returns (evidence_text, fused_docs).
    """
    q = _build_fusion_query(profile, lesson, session_context)

    constraints = profile.get("constraints", {}) or {}
    tags_filter = []
    dietary = constraints.get("dietary") or []
    if dietary:
        tags_filter.extend([str(x) for x in dietary if x])

    recipe_docs = retrieve_recipe_evidence(q, tags_filter=tags_filter or None, top_k_chunks=12)
    tech_docs = retrieve_technique_evidence(q, tags_filter=tags_filter or None, top_k=6)

    fused = rrf_fusion([recipe_docs, tech_docs], k=60)
    evidence_text = _format_evidence_context(fused, max_docs=8, max_chars=9000)
    return evidence_text, fused


SYSTEM_PROMPT = """You are ChefCoach, an expert cooking instructor who teaches like Duolingo teaches languages — progressively, with encouragement, and adapted to the learner's level.

Your teaching style:
- Warm, encouraging, but precise about technique
- Explain WHY, not just what (build understanding)
- Flag safety concerns clearly with ⚠️
- Include checkpoints: "pause here and observe..."
- Adjust language complexity to learner level
- Reference the learner's preferences and constraints

You MUST output in the following structured format:

## 🎯 Lesson Objective
[1-2 sentences about what the learner will master today]

## 📋 Mise en Place (What to Prepare)
[Numbered list of everything to gather/prep BEFORE turning on heat]

## 👨‍🍳 Step-by-Step Coaching
[Numbered steps with technique tips, timing, and checkpoints]
[Include "🔍 Checkpoint:" moments where learner should observe something]
[Include "💡 Why:" explanations for key techniques]

## ⚠️ Common Mistakes to Avoid
[3-4 common mistakes specific to this skill/recipe]

## 🧠 Reflection Questions
[2-3 questions to check understanding after cooking]

## 🏆 What You Learned
[Brief summary of the skill practiced and what to observe next time]
"""


def generate_coaching(
    profile: Dict[str, Any],
    lesson: Dict[str, Any],
    recipe_context: str,
    previous_feedback: Optional[Dict[str, Any]] = None,
    session_context: Optional[Dict[str, Any]] = None,
) -> str:
    """Generate a full coaching session."""

    # Multi-source RAG evidence (recipes + technique snippets) fused via RRF.
    evidence_text, fused_docs = _retrieve_fused_evidence(profile, lesson, session_context)

    # Keep backward compatibility: if caller still passes recipe packets context, include it as an additional reference.
    recipe_context_trimmed = (recipe_context or "").strip()
    if recipe_context_trimmed and len(recipe_context_trimmed) > 4500:
        recipe_context_trimmed = recipe_context_trimmed[:4500] + "\n\n[Recipe packets truncated for token budget.]"

    skill_vector_str = ", ".join(f"{k}: {v:.2f}" for k, v in profile.get("skill_vector", {}).items())

    constraints = profile.get("constraints", {})
    constraints_parts = []
    if constraints.get("dietary"):
        constraints_parts.append(f"Dietary: {', '.join(constraints['dietary'])}")
    if constraints.get("allergies"):
        constraints_parts.append(f"Allergies: {', '.join(constraints['allergies'])}")
    constraints_parts.append(f"Time budget: {constraints.get('time_budget_minutes', 30)} minutes")
    if constraints.get("equipment"):
        constraints_parts.append(f"Equipment: {', '.join(constraints.get('equipment', []))}")
    constraints_str = "; ".join(constraints_parts)

    taste_str = ", ".join(f"{k}: {v:.2f}" for k, v in profile.get("taste_prefs", {}).items())

    feedback_str = ""
    if previous_feedback:
        feedback_str = f"""
PREVIOUS SESSION FEEDBACK (use this to improve today):
- Rating: {previous_feedback.get('rating', 'N/A')}/5
- Difficulty felt: {previous_feedback.get('difficulty', 'N/A')}/5
- Notes: {previous_feedback.get('notes', 'None')}
- Quiz score: {previous_feedback.get('quiz_score', 'N/A')}
"""

    goal = ""
    ingredients = []
    if session_context:
        goal = str(session_context.get("goal", "")).strip()
        ingredients = session_context.get("ingredients", []) or []
        if isinstance(ingredients, str):
            ingredients = [x.strip() for x in ingredients.split(",") if x.strip()]

    session_block = ""
    if goal or ingredients:
        session_block = f"""
CURRENT SESSION INPUT:
- Learner goal: {goal or "N/A"}
- Available ingredients: {", ".join(ingredients) if ingredients else "N/A"}
"""

    user_prompt = f"""LEARNER PROFILE:
- Name: {profile.get('name', 'Learner')}
- Experience: {profile.get('experience_level', 'beginner')}
- Current Level: Lv{profile.get('current_level', 1)}
- Skill Vector: [{skill_vector_str}]
- Taste Preferences: [{taste_str}]
- Constraints: {constraints_str}
- Completed lessons: {len(profile.get('completed_lessons', []))}

TODAY'S LESSON:
- Title: {lesson['title']}
- Target Skill: {lesson['skill']}
- Difficulty Level: {lesson['difficulty']}/3
- Objective: {lesson['objective']}
- Technique Focus: {lesson.get('technique_focus', '')}
- Common Mistakes to Address: {', '.join(lesson.get('common_mistakes', []))}
- Safety Notes: {', '.join(lesson.get('safety_notes', []))}
{feedback_str}
{session_block}

EVIDENCE (multi-source, fused; prefer citing these facts when possible):
{evidence_text}

RETRIEVED RECIPE PACKETS (optional legacy packets; use only if helpful):
{recipe_context_trimmed if recipe_context_trimmed else '[none]'}

Generate a complete coaching session.
- Match difficulty to the learner.
- Be explicit about timing cues and sensory cues.
- Include at least 2 safety warnings if knives/heat/oil/oven are involved.
- Keep it practical: one practice dish, not multiple.
"""

    try:
        return chat(
            [
                ChatMessage(role="system", content=SYSTEM_PROMPT),
                ChatMessage(role="user", content=user_prompt),
            ],
            temperature=0.5,
            max_tokens=1800,
        )
    except Exception as e:
        return _fallback_coaching(lesson, recipe_context_trimmed, llm_error=str(e))


def generate_baseline_coaching(lesson: Dict[str, Any], recipe_context: str) -> str:
    """Baseline system: no memory, no curriculum context."""
    user_prompt = f"""Generate a cooking lesson for: {lesson['title']}
Objective: {lesson['objective']}

Use the retrieved recipe packets as reference:
{recipe_context}

Provide step-by-step instructions. Keep it generic (no personalization)."""

    try:
        return chat(
            [
                ChatMessage(role="system", content="You are a cooking instructor. Give clear cooking instructions."),
                ChatMessage(role="user", content=user_prompt),
            ],
            temperature=0.7,
            max_tokens=1500,
        )
    except Exception:
        return f"[Baseline] Basic instructions for {lesson['title']}: Follow the recipe steps carefully."


def answer_help_question(
    profile: Dict[str, Any],
    lesson: Dict[str, Any],
    current_coaching_text: str,
    user_question: str,
) -> str:
    """Answer an "I'm stuck" question during a lesson."""
    # Multi-source evidence for the user's exact help question (avoid over-anchoring to today's dish)
    recipe_docs = retrieve_recipe_evidence(user_question, top_k_chunks=10)
    tech_docs = retrieve_technique_evidence(user_question, top_k=5)
    fused = rrf_fusion([recipe_docs, tech_docs], k=60)
    user_q_evidence = _format_evidence_context(fused, max_docs=7, max_chars=4200)

    # Legacy packets (kept for backward compatibility)
    user_q_packets = retrieve_recipes(user_question, n_results=2)
    user_q_context = format_recipe_context(user_q_packets, max_recipes=2) if user_q_packets else ""

    evidence_block = f"\nQUESTION-SPECIFIC EVIDENCE (multi-source, fused):\n{user_q_evidence}\n" if user_q_evidence else ""

    snippet_text = format_technique_snippets(retrieve_technique_snippets(user_question, top_k=3))
    qna_block = f"\nRelevant technique notes (legacy snippets):\n{snippet_text}\n" if snippet_text else ""

    user_q_rag_block = (
        f"\nQUESTION-SPECIFIC RECIPE PACKETS (legacy packets):\n{user_q_context}\n" if user_q_context else ""
    )

    coaching_excerpt = (current_coaching_text or "").strip()[:1400]

    prompt = f"""A learner is currently doing this lesson:
- Lesson: {lesson['title']} (Skill: {lesson['skill']})
- Learner level: {profile.get('experience_level', 'beginner')}, Lv{profile.get('current_level', 1)}

Current coaching summary:
{coaching_excerpt}

The learner says: "{user_question}"
{evidence_block}
{user_q_rag_block}
{qna_block}

Respond rules:
1) Always answer the exact user question directly first.
2) If the user asks about a different ingredient/dish than today's lesson, answer that ingredient/dish directly first (do NOT force today's dish).
3) Use QUESTION-SPECIFIC RECIPE PACKETS first when available.
4) Then add one short bridge sentence back to today's lesson.
5) Keep it practical and clear, but not overly brief.
6) Default to medium detail (about 180-260 words) unless the user asks for a super short answer.

Output format:
- Direct answer: one short sentence + 5-8 numbered actionable steps
- Why this works: 2-3 bullets
- Quick check: 3-5 bullets to verify
- Safety: 1-2 short warnings if relevant
- Bridge: one short sentence linking back to today's lesson
"""

    try:
        return chat(
            [
                ChatMessage(
                    role="system",
                    content="You are ChefCoach. Be practical, specific, and moderately detailed. Prefer clear numbered steps."
                ),
                ChatMessage(role="user", content=prompt),
            ],
            temperature=0.15,
            max_tokens=700,
        )
    except Exception as e:
        err = str(e)
        if "429" in err or "quota" in err.lower() or "rate limit" in err.lower():
            return (
                "I couldn't reach Gemini just now because the API quota/rate limit was hit. "
                "Please wait about 1 minute and try again. "
                "If it keeps happening, reduce request frequency or switch provider/model.\n\n"
                "Quick fallback: pause heat, taste, and adjust one thing at a time."
            )
        return "I couldn't reach the LLM. Try: pause heat, taste, and describe what you see/smell/feel, then adjust one thing at a time."


def _fallback_coaching(lesson: Dict[str, Any], recipe_context: str, llm_error: str = "") -> str:
    """Fallback coaching when LLM is unavailable."""
    note = "ℹ️ Running in local fallback mode because the LLM is unavailable."
    err_lower = llm_error.lower()
    if "429" in llm_error or "quota" in err_lower or "rate limit" in err_lower:
        note = (
            "⚠️ API quota/rate limit was exceeded, so this lesson is shown in local fallback mode. "
            "Wait about 1 minute and retry."
        )
    elif "api key" in err_lower or "auth" in err_lower or "401" in llm_error:
        note = "ℹ️ API key is missing/invalid, so this lesson is shown in local fallback mode. Check `.env`."

    return f"""## 🎯 Lesson Objective
{lesson.get('objective', 'Practice a core cooking skill today.')}

## 📋 Mise en Place (What to Prepare)
1. Read the recipe packet once.
2. Gather ingredients, tools, and a timer.
3. Prep everything before turning on heat.

## 👨‍🍳 Step-by-Step Coaching
Use the recipe packets below as your step reference:

{recipe_context}

🔍 Checkpoint: After each step, pause and observe texture/color/smell.
💡 Why: Observations teach you *control* (heat, timing, seasoning).

## ⚠️ Common Mistakes to Avoid
- Rushing the prep
- Not tasting as you go
- Ignoring heat level changes

## 🧠 Reflection Questions
1. What changed when you adjusted heat?
2. Where did timing matter the most?

## 🏆 What You Learned
You practiced **{lesson.get('skill', 'a core skill')}**. Next time, focus on one improvement.

{note}
"""
