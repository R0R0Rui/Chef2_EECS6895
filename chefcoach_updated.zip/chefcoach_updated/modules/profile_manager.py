"""
Profile Manager (Modules 1-2)
Handles UserProfile creation, storage, and retrieval.
Stores: skill_vector, taste_prefs, constraints, equipment, history.
Backend: SQLite database.
"""

import json
import sqlite3
import os
from datetime import datetime

DB_PATH = os.getenv("SQLITE_DB_PATH", "./chefcoach.db")
SKILLS_PATH = os.path.join(os.path.dirname(__file__), "..", "data", "skills.json")


def _get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    """Create tables if they don't exist."""
    conn = _get_db()
    conn.executescript("""
        CREATE TABLE IF NOT EXISTS users (
            user_id TEXT PRIMARY KEY,
            profile_json TEXT NOT NULL,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS sessions (
            session_id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id TEXT NOT NULL,
            lesson_id TEXT,
            lesson_output TEXT,
            feedback_json TEXT,
            created_at TEXT NOT NULL,
            FOREIGN KEY (user_id) REFERENCES users(user_id)
        );
    """)
    conn.commit()
    conn.close()


def get_default_skill_vector():
    """Return a skill vector with all skills at 0.0."""
    with open(SKILLS_PATH) as f:
        skills_data = json.load(f)
    return {s["id"]: 0.0 for s in skills_data["skills"]}


def create_profile(user_id, name="Learner", dietary=None, equipment=None,
                   cuisines=None, time_budget=30, experience_level="beginner"):
    """Create a new user profile with initial skill vector."""
    init_db()
    profile = {
        "user_id": user_id,
        "name": name,
        "skill_vector": get_default_skill_vector(),
        "taste_prefs": {
            "spicy": 0.5, "sweet": 0.5, "sour": 0.5,
            "salty": 0.5, "umami": 0.5
        },
        "constraints": {
            "dietary": dietary or [],
            "allergies": [],
            "equipment": equipment or ["stove", "oven", "basic_pots"],
            "time_budget_minutes": time_budget,
            "preferred_cuisines": cuisines or []
        },
        "experience_level": experience_level,
        "completed_lessons": [],
        "skill_state": {},
        "skill_confidence": {},
        "cluster_id": "C1",
        "current_level": 1,
        "total_sessions": 0
    }
    conn = _get_db()
    now = datetime.now().isoformat()
    conn.execute(
        "INSERT OR REPLACE INTO users (user_id, profile_json, created_at, updated_at) VALUES (?, ?, ?, ?)",
        (user_id, json.dumps(profile), now, now)
    )
    conn.commit()
    conn.close()
    return profile


def get_profile(user_id):
    """Retrieve user profile from DB. Returns None if not found."""
    init_db()
    conn = _get_db()
    row = conn.execute("SELECT profile_json FROM users WHERE user_id = ?", (user_id,)).fetchone()
    conn.close()
    if row:
        return json.loads(row["profile_json"])
    return None


def save_profile(profile):
    """Save updated profile to DB."""
    conn = _get_db()
    now = datetime.now().isoformat()
    conn.execute(
        "UPDATE users SET profile_json = ?, updated_at = ? WHERE user_id = ?",
        (json.dumps(profile), now, profile["user_id"])
    )
    conn.commit()
    conn.close()


def save_session(user_id, lesson_id, lesson_output, feedback=None):
    """Record a coaching session."""
    init_db()
    conn = _get_db()
    conn.execute(
        "INSERT INTO sessions (user_id, lesson_id, lesson_output, feedback_json, created_at) VALUES (?, ?, ?, ?, ?)",
        (user_id, lesson_id, lesson_output, json.dumps(feedback) if feedback else None, datetime.now().isoformat())
    )
    conn.commit()
    conn.close()


def get_sessions(user_id, limit=10):
    """Get recent sessions for a user."""
    init_db()
    conn = _get_db()
    rows = conn.execute(
        "SELECT * FROM sessions WHERE user_id = ? ORDER BY created_at DESC LIMIT ?",
        (user_id, limit)
    ).fetchall()
    conn.close()
    results = []
    for r in rows:
        results.append({
            "session_id": r["session_id"],
            "lesson_id": r["lesson_id"],
            "lesson_output": r["lesson_output"],
            "feedback": json.loads(r["feedback_json"]) if r["feedback_json"] else None,
            "created_at": r["created_at"]
        })
    return results


def reset_user_memory(user_id):
    """
    Clear all persisted memory for one user:
    - profile row in users
    - session history rows in sessions
    """
    init_db()
    conn = _get_db()
    conn.execute("DELETE FROM sessions WHERE user_id = ?", (user_id,))
    conn.execute("DELETE FROM users WHERE user_id = ?", (user_id,))
    conn.commit()
    conn.close()


def get_skill_level_label(skill_value):
    """Convert numeric skill to label."""
    if skill_value < 0.3:
        return "Beginner"
    elif skill_value < 0.6:
        return "Intermediate"
    else:
        return "Advanced"


def calculate_overall_level(skill_vector):
    """Calculate overall learner level (Lv1-Lv5) from skill vector."""
    avg = sum(skill_vector.values()) / len(skill_vector) if skill_vector else 0
    if avg < 0.15:
        return 1
    elif avg < 0.3:
        return 2
    elif avg < 0.5:
        return 3
    elif avg < 0.7:
        return 4
    else:
        return 5
