# modules/level_system.py
from __future__ import annotations
from dataclasses import dataclass
from typing import Dict, Tuple

LEVEL_XP_THRESHOLDS = [0, 100, 250, 450, 700, 1000]  # Lv1..Lv6 thresholds

def xp_to_level(xp: float) -> Tuple[int, float, float]:
    """return (level, xp_in_level, xp_needed_this_level)"""
    level = 1
    for i in range(1, len(LEVEL_XP_THRESHOLDS)):
        if xp >= LEVEL_XP_THRESHOLDS[i]:
            level = i + 1
        else:
            break
    lo = LEVEL_XP_THRESHOLDS[level - 1]
    hi = LEVEL_XP_THRESHOLDS[min(level, len(LEVEL_XP_THRESHOLDS) - 1)]
    if level >= len(LEVEL_XP_THRESHOLDS):
        hi = lo + 400
    return level, xp - lo, max(1.0, hi - lo)

def compute_overall_level(skill_state: Dict[str, Dict]) -> int:
    """skill_state: {skill_id: {'xp':..., 'level':..., ...}}"""
    if not skill_state:
        return 1
    avg_level = sum(v.get("level", 1) for v in skill_state.values()) / len(skill_state)
    return max(1, int(round(avg_level)))