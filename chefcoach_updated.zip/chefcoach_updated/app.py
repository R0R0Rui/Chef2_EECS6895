"""
ChefCoach — Streamlit Application
Entry point: streamlit run app.py
"""

from __future__ import annotations

import html
import io
import json
import os
from datetime import datetime
from typing import Dict, List

import plotly.graph_objects as go
import streamlit as st
import streamlit.components.v1 as components
from dotenv import load_dotenv
from PIL import Image, UnidentifiedImageError

try:
    from pillow_heif import register_heif_opener
except Exception:
    register_heif_opener = None

from modules.coach_generator import answer_help_question, generate_coaching
from modules.curriculum_planner import get_all_skills, get_curriculum_state, get_skill_info
from modules.feedback_updater import get_feedback_summary, update_profile
from modules.profile_manager import (
    create_profile,
    get_profile,
    get_sessions,
    init_db,
    reset_user_memory,
    save_profile,
    save_session,
)
from modules.learner_clustering import assign_cluster, build_feature_vector
from modules.rag_retriever import format_recipe_context, retrieve_recipes
from modules.skill_assessor import get_assessment_questions, process_assessment
from modules.llm_client import LLMError, analyze_image, get_provider


load_dotenv()

if register_heif_opener is not None:
    try:
        register_heif_opener()
    except Exception:
        pass


def has_openai_key() -> bool:
    """Return True when the currently selected provider is configured."""
    try:
        load_dotenv(override=False)
    except Exception:
        pass

    provider = os.getenv("LLM_PROVIDER", "gemini").strip().lower()
    if provider == "gemini":
        key = os.getenv("GEMINI_API_KEY")
        return bool(key and str(key).strip())
    if provider == "openai":
        key = os.getenv("OPENAI_API_KEY")
        return bool(key and str(key).strip())
    return True


def render_missing_key_block() -> None:
    provider = os.getenv("LLM_PROVIDER", "gemini").strip().lower()
    if provider == "gemini":
        body = (
            "Gemini API key not detected. ChefCoach will use local fallback coaching/help so you can keep practicing.\n\n"
            "Add an API key for higher-quality generation.\n\n"
            "Create a `.env` file in the project root (same folder as `app.py`) and add:\n"
            "`GEMINI_API_KEY=...`\n\n"
            "Then restart Streamlit."
        )
    else:
        body = (
            "OpenAI-compatible API key not detected. ChefCoach will use local fallback coaching/help so you can keep practicing.\n\n"
            "Add an API key for higher-quality generation.\n\n"
            "Create a `.env` file in the project root (same folder as `app.py`) and add:\n"
            "`OPENAI_API_KEY=...`\n\n"
            "Then restart Streamlit."
        )
    st.warning(body, icon="🔑")



st.set_page_config(
    page_title="ChefCoach — AI Cooking Coach",
    page_icon="🍳",
    layout="wide",
    initial_sidebar_state="expanded",
)

init_db()


def apply_theme() -> None:
    st.markdown(
        """
<style>
:root {
  --chef-bg: #5a2a19;
  --chef-bg-soft: #39190e;
  --chef-panel: rgba(92, 50, 29, 0.74);
  --chef-panel-strong: rgba(103, 58, 34, 0.90);
  --chef-sidebar: #542817;
  --chef-sidebar-soft: #3b1b10;
  --chef-border: rgba(225, 150, 108, 0.28);
  --chef-border-strong: rgba(225, 150, 108, 0.54);
  --chef-text: #f6eddc;
  --chef-text-soft: #dfcbb3;
  --chef-accent: #d99163;
  --chef-accent-deep: #bf764b;
  --chef-accent-soft: rgba(202, 132, 87, 0.14);
  --chef-success: #92a985;
  --chef-success-soft: rgba(146, 169, 133, 0.18);
  --chef-input: #f4e8d8;
  --chef-input-border: rgba(125, 84, 60, 0.26);
  --chef-input-text: #563426;
  --chef-chip: #ead1b4;
  --chef-chip-text: #6d4732;
  --chef-shadow: 0 16px 36px rgba(17, 6, 2, 0.18);
}

html, body, [class*="css"] {
  color: var(--chef-text);
}

[data-testid="stAppViewContainer"] {
  background:
    radial-gradient(circle at top left, rgba(202, 132, 87, 0.12), transparent 24%),
    linear-gradient(180deg, var(--chef-bg) 0%, var(--chef-bg-soft) 100%);
  color: var(--chef-text);
}

[data-testid="stHeader"] {
  background: rgba(0, 0, 0, 0);
}

[data-testid="stSidebar"] {
  background: linear-gradient(180deg, var(--chef-sidebar) 0%, var(--chef-sidebar-soft) 100%);
  border-right: 1px solid rgba(248, 232, 214, 0.12);
}

[data-testid="stSidebar"] * {
  color: #f8efe0;
}

section[data-testid="stSidebar"] hr {
  border-color: rgba(248, 232, 214, 0.14);
}

div.block-container {
  padding-top: 1.25rem;
  max-width: 1150px;
}

h1, h2, h3, h4, h5, h6 {
  color: var(--chef-text);
}

p, li, label, span, small {
  color: var(--chef-text-soft);
}

[data-testid="stMetric"] {
  background: var(--chef-panel);
  border: 1px solid var(--chef-border);
  border-radius: 14px;
  box-shadow: var(--chef-shadow);
  padding: 0.85rem 1rem;
}

[data-testid="stMetricLabel"],
[data-testid="stMetricLabel"] * {
  color: var(--chef-text-soft);
}

[data-testid="stMetricValue"] {
  color: var(--chef-text);
}

.stForm,
[data-testid="stExpander"],
[data-testid="stVerticalBlockBorderWrapper"] {
  background: var(--chef-panel);
  border: 1px solid var(--chef-border);
  border-radius: 16px;
  box-shadow: var(--chef-shadow);
}

[data-testid="stSidebar"] [data-testid="stExpander"] {
  background: rgba(248, 239, 224, 0.08);
  border: 1px solid rgba(248, 239, 224, 0.14);
}

[data-testid="stSidebar"] [data-testid="stExpander"] summary,
[data-testid="stSidebar"] [data-testid="stExpander"] summary * {
  color: #f8efe0 !important;
}

[data-testid="stSidebar"] [data-testid="stExpanderDetails"] p,
[data-testid="stSidebar"] [data-testid="stExpanderDetails"] div,
[data-testid="stSidebar"] [data-testid="stExpanderDetails"] span,
[data-testid="stSidebar"] [data-testid="stExpanderDetails"] small {
  color: #e7d7c4 !important;
}

[data-testid="stSidebar"] .flow-panel {
  background: rgba(248, 239, 224, 0.12);
  border: 1px solid rgba(248, 239, 224, 0.22);
}

[data-testid="stSidebar"] .flow-item {
  background: rgba(248, 239, 224, 0.12);
  border: 1px solid rgba(248, 239, 224, 0.18);
  color: #f8efe0;
}

[data-testid="stSidebar"] .flow-item-active {
  background: rgba(202, 132, 87, 0.20);
  border: 1px solid rgba(225, 150, 108, 0.42);
}

[data-testid="stSidebar"] .flow-item-done {
  background: rgba(146, 169, 133, 0.18);
  border: 1px solid rgba(146, 169, 133, 0.30);
}

.stTextInput [data-baseweb="base-input"],
.stTextInput [data-baseweb="input"],
.stTextArea [data-baseweb="base-textarea"],
.stTextArea [data-baseweb="textarea"],
.stSelectbox div[data-baseweb="select"] > div,
.stMultiSelect div[data-baseweb="select"] > div,
.stNumberInput [data-baseweb="base-input"],
.stNumberInput [data-baseweb="input"] {
  background: var(--chef-input) !important;
  color: var(--chef-input-text) !important;
  border: 1px solid var(--chef-input-border) !important;
  border-radius: 12px !important;
  outline: none !important;
  box-shadow: none !important;
}

.stTextInput input,
.stTextArea textarea,
.stNumberInput input,
.stTextInput [data-baseweb="input"] input,
.stTextArea [data-baseweb="textarea"] textarea,
.stTextArea [data-baseweb="base-textarea"] textarea,
.stNumberInput [data-baseweb="input"] input,
.stTextInput > div > div > input,
.stTextArea > div > div > textarea,
.stTextInput > div > div,
.stTextArea > div > div,
.stNumberInput > div > div > input {
  background: var(--chef-input) !important;
  color: var(--chef-input-text) !important;
  -webkit-text-fill-color: var(--chef-input-text) !important;
  border: 0 !important;
  outline: none !important;
  box-shadow: none !important;
  caret-color: var(--chef-input-text) !important;
}

.stTextInput input:focus,
.stTextArea textarea:focus,
.stNumberInput input:focus,
.stSelectbox div[data-baseweb="select"] > div:focus-within,
.stMultiSelect div[data-baseweb="select"] > div:focus-within,
.stTextInput [data-baseweb="base-input"]:focus-within,
.stTextArea [data-baseweb="base-textarea"]:focus-within,
.stNumberInput [data-baseweb="base-input"]:focus-within {
  border: 1px solid rgba(202, 132, 87, 0.50) !important;
  outline: none !important;
  box-shadow: 0 0 0 2px rgba(202, 132, 87, 0.14) !important;
}

.stTextInput input::placeholder,
.stTextArea textarea::placeholder {
  color: rgba(105, 74, 57, 0.72) !important;
}

.stMultiSelect [data-baseweb="tag"] {
  background: var(--chef-chip) !important;
  border: 1px solid rgba(125, 84, 60, 0.12) !important;
  color: var(--chef-chip-text) !important;
}

.stMultiSelect [data-baseweb="tag"] *,
.stMultiSelect [data-baseweb="tag"] span {
  color: var(--chef-chip-text) !important;
}

.stMultiSelect [data-baseweb="tag"] svg,
.stMultiSelect [data-baseweb="tag"] path {
  fill: #94684f !important;
  stroke: #94684f !important;
}

.stCheckbox label,
.stRadio label,
.stRadio [role="radiogroup"] label {
  color: var(--chef-text) !important;
}

.stRadio input[type="radio"],
.stCheckbox input[type="checkbox"],
input[type="radio"],
input[type="checkbox"] {
  appearance: none !important;
  -webkit-appearance: none !important;
  width: 1rem !important;
  height: 1rem !important;
  margin-right: 0.35rem !important;
  background: #fff8ef !important;
  border: 1.5px solid rgba(125, 84, 60, 0.34) !important;
  box-shadow: none !important;
  display: inline-grid !important;
  place-content: center !important;
  vertical-align: middle !important;
}

.stRadio input[type="radio"],
input[type="radio"] {
  border-radius: 50% !important;
}

.stCheckbox input[type="checkbox"],
input[type="checkbox"] {
  border-radius: 4px !important;
}

.stRadio input[type="radio"]::before,
input[type="radio"]::before {
  content: "";
  width: 0.48rem;
  height: 0.48rem;
  border-radius: 50%;
  transform: scale(0);
  transition: transform 120ms ease-in-out;
  box-shadow: inset 1em 1em var(--chef-accent);
}

.stCheckbox input[type="checkbox"]::before,
input[type="checkbox"]::before {
  content: "";
  width: 0.52rem;
  height: 0.52rem;
  transform: scale(0);
  transition: transform 120ms ease-in-out;
  box-shadow: inset 1em 1em var(--chef-accent);
}

.stRadio input[type="radio"]:checked::before,
input[type="radio"]:checked::before,
.stCheckbox input[type="checkbox"]:checked::before,
input[type="checkbox"]:checked::before {
  transform: scale(1);
}

.stRadio [data-baseweb="radio"] > div:first-child,
.stCheckbox [data-baseweb="checkbox"] > div:first-child,
.stRadio [role="radiogroup"] label > div:first-child,
.stCheckbox label > div:first-child {
  background: #fff8ef !important;
  border-color: rgba(125, 84, 60, 0.24) !important;
  box-shadow: none !important;
}

.stRadio [role="radiogroup"] label:has(input:checked) > div:first-child,
.stCheckbox label:has(input:checked) > div:first-child,
.stRadio [data-baseweb="radio"]:has(input:checked) > div:first-child,
.stCheckbox [data-baseweb="checkbox"]:has(input:checked) > div:first-child {
  background: var(--chef-accent) !important;
  border-color: var(--chef-accent-deep) !important;
}

.stSlider [data-baseweb="slider"] > div > div {
  background: var(--chef-accent) !important;
}

.stButton > button[kind="primary"],
[data-testid="stFormSubmitButton"] > button,
button[kind="primary"],
[data-testid="stBaseButton-primary"] {
  background: linear-gradient(180deg, var(--chef-accent) 0%, var(--chef-accent-deep) 100%) !important;
  color: #fff7ef !important;
  border: 1px solid rgba(255, 232, 214, 0.12) !important;
  border-radius: 12px !important;
  box-shadow: 0 8px 18px rgba(118, 56, 28, 0.20) !important;
  transition: filter 140ms ease, transform 140ms ease, box-shadow 140ms ease, background 140ms ease !important;
}

.stButton > button[kind="primary"]:hover,
[data-testid="stFormSubmitButton"] > button:hover,
button[kind="primary"]:hover,
[data-testid="stBaseButton-primary"]:hover {
  background: linear-gradient(180deg, #c57a4f 0%, #9e5a36 100%) !important;
  border-color: rgba(255, 232, 214, 0.26) !important;
  transform: translateY(1px);
  box-shadow: 0 5px 12px rgba(88, 40, 19, 0.24) !important;
  filter: none !important;
}


[data-testid="stFileUploaderDropzone"] {
  background: rgba(244, 232, 216, 0.08) !important;
  border: 1px dashed rgba(225, 150, 108, 0.34) !important;
  border-radius: 14px !important;
  box-shadow: inset 0 0 0 1px rgba(255, 236, 220, 0.04) !important;
}

[data-testid="stFileUploaderDropzone"] * {
  color: var(--chef-text) !important;
}

[data-testid="stFileUploaderDropzone"] small,
[data-testid="stFileUploaderDropzone"] span,
[data-testid="stFileUploaderDropzone"] p {
  color: var(--chef-text-soft) !important;
}

[data-testid="stFileUploaderDropzone"] section {
  background: transparent !important;
}

[data-testid="stFileUploaderDropzone"] [data-testid="stBaseButton-secondary"] {
  background: rgba(248, 239, 224, 0.10) !important;
  border: 1px solid rgba(248, 239, 224, 0.16) !important;
  color: var(--chef-text) !important;
}

[data-testid="stFileUploaderDropzone"] [data-testid="stBaseButton-secondary"]:hover {
  background: rgba(248, 239, 224, 0.16) !important;
  border-color: rgba(248, 239, 224, 0.24) !important;
}

.stButton > button,
.stDownloadButton > button {
  border-radius: 12px;
}

.stButton > button[kind="secondary"],
.stDownloadButton > button[kind="secondary"] {
  background: rgba(248, 239, 224, 0.08);
  color: var(--chef-text) !important;
  border: 1px solid var(--chef-border);
  box-shadow: none;
}

[data-testid="stSidebar"] .stButton > button,
[data-testid="stSidebar"] .stDownloadButton > button,
[data-testid="stSidebar"] .stButton > button[kind="secondary"] {
  color: #f8efe0 !important;
  background: rgba(248, 239, 224, 0.08);
  border: 1px solid rgba(248, 239, 224, 0.18);
}

[data-testid="stSidebar"] .stButton > button:hover,
[data-testid="stSidebar"] .stDownloadButton > button:hover {
  background: rgba(248, 239, 224, 0.12);
}

.stProgress,
[data-testid="stProgressBar"] {
  background: transparent !important;
}

.stProgress > div > div,
[data-testid="stProgressBar"] > div {
  background: rgba(227, 186, 153, 0.30) !important;
  border: 1px solid rgba(227, 186, 153, 0.08) !important;
  border-radius: 999px !important;
  box-shadow: none !important;
}

.stProgress > div > div > div > div,
[data-testid="stProgressBar"] div[role="progressbar"] {
  background: linear-gradient(90deg, #efc7a2 0%, var(--chef-accent) 100%) !important;
  border-radius: 999px !important;
  box-shadow: none !important;
}

.stCodeBlock {
  background: rgba(36, 14, 8, 0.52);
  border: 1px solid rgba(225, 150, 108, 0.18);
}

.stAlert,
[data-testid="stAlert"],
[data-testid="stAlertContainer"],
[data-baseweb="notification"],
[role="alert"] {
  background: rgba(248, 239, 224, 0.10) !important;
  border: 1px solid rgba(225, 150, 108, 0.24) !important;
  color: var(--chef-text) !important;
  box-shadow: none !important;
}

[data-baseweb="notification"] *,
[data-testid="stAlert"] *,
[role="alert"] * {
  color: var(--chef-text) !important;
}

.chef-step {
  display: inline-block;
  margin: 0 6px 8px 0;
  padding: 4px 10px;
  border-radius: 999px;
  border: 1px solid var(--chef-border);
  font-size: 0.82rem;
  color: var(--chef-text-soft);
  background: rgba(248, 239, 224, 0.06);
}

.flow-step-done {
  color: var(--chef-success);
  font-weight: 600;
}

.flow-panel {
  border: 1px solid var(--chef-border);
  border-radius: 14px;
  padding: 10px 12px;
  margin-top: 6px;
  background: rgba(248, 239, 224, 0.07);
}

.flow-item {
  margin: 6px 0;
  padding: 8px 10px;
  border-radius: 10px;
  border: 1px solid rgba(225, 150, 108, 0.18);
  background: rgba(248, 239, 224, 0.08);
  color: var(--chef-text);
}

.flow-item-active {
  background: rgba(202, 132, 87, 0.14);
  border: 1px solid var(--chef-border-strong);
}

.flow-item-done {
  background: var(--chef-success-soft);
  border: 1px solid rgba(146, 169, 133, 0.42);
}

.flow-item-pending {
  opacity: 0.92;
}
</style>
""",
        unsafe_allow_html=True,
    )

def ensure_state() -> None:
    defaults = {
        "user_id": "default_user",
        "current_lesson": None,
        "current_coaching": None,
        "help_answer": None,
        "vision_answer": None,
        "vision_error": "",
        "vision_filename": "",
        "vision_hint": "",
        "clear_vision_hint": False,
        "quiz_score": 0.5,
        "session_goal": "",
        "session_ingredients_text": "",
        "session_packets": [],
        "flow_step": "onboarding",
        "pending_auto_generate": False,
        "flash_notice": None,
        "last_saved_at": "",
        "scroll_target": "",
    }
    for key, value in defaults.items():
        if key not in st.session_state:
            st.session_state[key] = value


def request_scroll_top() -> None:
    st.session_state.scroll_target = "chef-top-anchor"


def request_scroll_anchor(anchor_id: str) -> None:
    st.session_state.scroll_target = anchor_id


def maybe_scroll_top() -> None:
    target = (st.session_state.pop("scroll_target", "") or "").strip()
    if not target:
        return
    components.html(
        f"""
<script>
  const targetId = {target!r};

  function scrollToTargetFor(winObj) {{
    if (!winObj || !winObj.document) return;
    const doc = winObj.document;
    const anchor = doc.getElementById(targetId);
    if (anchor && anchor.scrollIntoView) {{
      anchor.scrollIntoView({{ block: "start", behavior: "auto" }});
      return;
    }}

    if (targetId === "chef-top-anchor") {{
      const selectors = [
        '[data-testid="stAppViewContainer"]',
        '[data-testid="stMain"]',
        "section.main",
        "main",
        ".stApp",
      ];
      for (const sel of selectors) {{
        const el = doc.querySelector(sel);
        if (el && el.scrollTo) el.scrollTo({{ top: 0, behavior: "auto" }});
        if (el) el.scrollTop = 0;
      }}
      if (doc.documentElement) doc.documentElement.scrollTop = 0;
      if (doc.body) doc.body.scrollTop = 0;
      if (winObj.scrollTo) winObj.scrollTo(0, 0);
    }}
  }}

  function forceBoth() {{
    try {{ scrollToTargetFor(window); }} catch (e) {{}}
    try {{ scrollToTargetFor(window.parent); }} catch (e) {{}}
  }}

  forceBoth();
  let tries = 0;
  const timer = setInterval(() => {{
    forceBoth();
    tries += 1;
    if (tries >= 12) clearInterval(timer);
  }}, 120);
</script>
""",
        height=0,
    )


def push_flash_notice(
    message: str,
    *,
    kind: str = "success",
    balloons: bool = False,
    step: int | None = None,
    total_steps: int = 3,
) -> None:
    st.session_state.flash_notice = {
        "message": message,
        "kind": kind,
        "balloons": balloons,
        "step": step,
        "total_steps": total_steps,
    }


def render_flash_notice() -> None:
    notice = st.session_state.pop("flash_notice", None)
    if not notice:
        return

    msg = str(notice.get("message", "")).strip()
    kind = str(notice.get("kind", "success")).strip().lower()
    balloons = bool(notice.get("balloons", False))
    step = notice.get("step")
    total_steps = notice.get("total_steps", 3)
    if not msg:
        return

    prefix = ""
    if isinstance(step, int) and step > 0 and isinstance(total_steps, int) and total_steps > 0:
        prefix = f"[{step}/{total_steps}] "
    display_msg = f"{prefix}{msg}"

    if kind == "error":
        icon = "❌"
    elif kind == "warning":
        icon = "⚠️"
    else:
        # Success notices are shown as lightweight toast only,
        # so we don't keep a full-width green bar at the top.
        icon = "✅"

    # toast is optional; keep app compatible if unavailable
    try:
        st.toast(display_msg, icon=icon)
    except Exception:
        # Fallback only if toast is unavailable.
        if kind == "error":
            st.error(display_msg)
        elif kind == "warning":
            st.warning(display_msg)
        else:
            st.caption(f"{icon} {display_msg}")

    if balloons:
        st.balloons()


def parse_ingredients(raw: str) -> List[str]:
    chunks = [x.strip() for x in (raw or "").replace("\n", ",").split(",")]
    return [c for c in chunks if c]


def validate_upload_image(image_bytes: bytes, filename: str = "") -> tuple[bool, str]:
    if not image_bytes:
        return False, "The uploaded file is empty."
    suffix = (filename or "").lower().rsplit(".", 1)[-1] if "." in (filename or "") else ""
    try:
        with Image.open(io.BytesIO(image_bytes)) as img:
            img.verify()
        return True, ""
    except UnidentifiedImageError:
        if suffix in {"heic", "heif"} and register_heif_opener is None:
            return False, "HEIC support is not installed yet. Run `pip install -r requirements.txt` and restart Streamlit."
        if suffix in {"heic", "heif"}:
            return False, "This HEIC file could not be decoded. Re-export it as JPG or PNG and try again."
        return False, "This file could not be decoded as an image. Export it as PNG or JPG and try again."
    except Exception as e:
        return False, f"Image validation failed: {e}"


def load_index_summary() -> Dict:
    path = os.path.join(os.path.dirname(__file__), "data", "index_summary.json")
    if not os.path.exists(path):
        return {}
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def render_sidebar_progress(profile: Dict | None, flow_step: str) -> None:
    st.sidebar.title("🍳 ChefCoach")
    st.sidebar.markdown("*Your AI Cooking Coach*")
    st.sidebar.divider()

    step_order = {
        "onboarding": 1,
        "guided": 2,
        "dashboard": 3,
    }
    current = step_order.get(flow_step, 1)

    def step_row(idx: int, label: str) -> str:
        if idx < current:
            cls = "flow-item flow-item-done"
            prefix = "☑"
        elif idx == current:
            cls = "flow-item flow-item-active"
            prefix = "☐"
        else:
            cls = "flow-item flow-item-pending"
            prefix = "☐"
        return f'<div class="{cls}">{prefix} {label}</div>'

    st.sidebar.markdown("**Current Journey**")
    st.sidebar.markdown(
        (
            '<div class="flow-panel">'
            + step_row(1, "Onboarding")
            + step_row(2, "Lesson & Practice")
            + step_row(3, "Dashboard")
            + "</div>"
        ),
        unsafe_allow_html=True,
    )

    if profile:
        st.sidebar.divider()
        st.sidebar.markdown(f"**Learner:** {profile.get('name', 'Learner')}")
        st.sidebar.markdown(f"**Level:** Lv{profile.get('current_level', 1)}")
        st.sidebar.markdown(f"**Sessions:** {profile.get('total_sessions', 0)}")
        st.sidebar.markdown(f"**Lessons Done:** {len(profile.get('completed_lessons', []))}")
        if st.session_state.get("last_saved_at"):
            st.sidebar.caption(f"Last saved: {st.session_state['last_saved_at']}")
        if flow_step != "onboarding" and st.sidebar.button("✏️ Edit Onboarding", width="stretch"):
            st.session_state.flow_step = "onboarding"
            request_scroll_top()
            st.rerun()

        with st.sidebar.expander("🧹 Reset Memory", expanded=False):
            st.caption("Clear this user's profile + session history on this machine.")
            if st.button("Reset Now", key="reset_memory_btn", type="secondary", width="stretch"):
                reset_user_memory(st.session_state.user_id)
                st.session_state.current_lesson = None
                st.session_state.current_coaching = None
                st.session_state.help_answer = None
                st.session_state.vision_answer = None
                st.session_state.vision_error = ""
                st.session_state.vision_filename = ""
                st.session_state["clear_vision_hint"] = True
                st.session_state.quiz_score = 0.5
                st.session_state.session_goal = ""
                st.session_state.session_ingredients_text = ""
                st.session_state.session_packets = []
                st.session_state.flow_step = "onboarding"
                st.session_state.pending_auto_generate = False
                st.session_state.last_saved_at = ""
                push_flash_notice(
                    "Memory reset complete. Start from Onboarding.",
                    kind="success",
                    step=1,
                )
                request_scroll_top()
                st.rerun()


def render_banner(title: str, subtitle: str) -> None:
    st.markdown(f"## {title}")
    st.caption(subtitle)


def render_onboarding(profile: Dict | None) -> None:
    render_banner("🏁 Onboarding", "Set your profile once, then ChefCoach will adapt every session.")

    with st.form("onboarding_form"):
        col1, col2 = st.columns(2)
        with col1:
            name = st.text_input("Your name", value=profile["name"] if profile else "")
            experience = st.selectbox(
                "Cooking experience",
                ["beginner", "intermediate", "advanced"],
                index=["beginner", "intermediate", "advanced"].index(profile["experience_level"]) if profile else 0,
            )
            time_budget = st.slider(
                "Time budget per session (minutes)",
                15,
                120,
                profile["constraints"]["time_budget_minutes"] if profile else 30,
            )

        with col2:
            dietary = st.multiselect(
                "Dietary restrictions",
                ["vegetarian", "vegan", "gluten-free", "dairy-free", "nut-free", "halal", "kosher"],
                default=profile["constraints"]["dietary"] if profile else [],
            )
            equipment = st.multiselect(
                "Equipment",
                [
                    "stove",
                    "oven",
                    "microwave",
                    "wok",
                    "blender",
                    "food_processor",
                    "stand_mixer",
                    "grill",
                    "instant_pot",
                    "basic_pots",
                    "baking_sheets",
                ],
                default=profile["constraints"]["equipment"] if profile else ["stove", "oven", "basic_pots"],
            )
            cuisines = st.multiselect(
                "Preferred cuisines",
                ["Italian", "Chinese", "Japanese", "Mexican", "Indian", "French", "Thai", "Korean", "American", "Mediterranean"],
                default=profile["constraints"].get("preferred_cuisines", []) if profile else [],
            )

        st.markdown("### 🧪 Skill Assessment")
        answers = {}
        for q in get_assessment_questions():
            default_idx = 0
            if profile:
                skill_val = profile["skill_vector"].get(q["skill"], 0)
                for i, opt in enumerate(q["options"]):
                    if abs(opt["delta"] - skill_val) < 0.15:
                        default_idx = i
                        break
            answers[q["skill"]] = st.radio(
                q["question"],
                options=range(len(q["options"])),
                format_func=lambda i, q=q: q["options"][i]["text"],
                index=default_idx,
                key=f"quiz_{q['skill']}",
            )

        submitted = st.form_submit_button("Save Profile", type="primary", width="stretch")
        if submitted:
            new_profile = create_profile(
                user_id=st.session_state.user_id,
                name=name,
                dietary=dietary,
                equipment=equipment,
                cuisines=cuisines,
                time_budget=time_budget,
                experience_level=experience,
            )
            new_profile["skill_vector"] = process_assessment(answers)
            save_profile(new_profile)
            st.session_state.current_lesson = None
            st.session_state.current_coaching = None
            st.session_state.help_answer = None
            st.session_state.vision_answer = None
            st.session_state.vision_error = ""
            st.session_state.vision_filename = ""
            st.session_state["clear_vision_hint"] = True
            st.session_state.session_packets = []
            st.session_state.quiz_score = 0.5
            st.session_state.flow_step = "guided"
            st.session_state.pending_auto_generate = True
            ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            st.session_state.last_saved_at = ts
            push_flash_notice(
                "Profile saved successfully. Auto-starting your first guided session.",
                balloons=True,
                step=2,
            )
            request_scroll_top()
            st.rerun()


def render_recipe_packets(packets: List[Dict]) -> None:
    if not packets:
        return
    st.markdown("### 🔎 Retrieved Recipe Packets")
    st.caption("These are RAG-retrieved reference recipe packets. They are not buttons; expand each row to view ingredients and steps.")
    for i, pkt in enumerate(packets[:3], start=1):
        title = pkt.get("title") or pkt.get("recipe_id")
        rid = pkt.get("recipe_id")
        matched = ", ".join(pkt.get("matched_chunk_types", [])) or "N/A"
        rating = pkt.get("rating")
        rating_text = f" | ⭐ {rating:.2f} (n={pkt.get('rating_count', 0)})" if rating is not None else ""
        with st.expander(f"{i}. {title}  |  id={rid}  |  matched={matched}{rating_text}", expanded=False):
            chunks = pkt.get("chunks", {})
            title_chunk = chunks.get("title", "").strip()
            ing_chunk = chunks.get("ingredients", "").strip()
            step_chunk = chunks.get("steps", "").strip()
            if title_chunk:
                st.markdown("**Title/Tags Chunk**")
                st.code(title_chunk, language="text")
            if ing_chunk:
                st.markdown("**Ingredients Chunk**")
                st.code(ing_chunk, language="text")
            if step_chunk:
                st.markdown("**Steps Chunk**")
                st.code(step_chunk, language="text")


def render_guided_session(profile: Dict | None) -> None:
    if st.session_state.pop("clear_vision_hint", False):
        st.session_state["vision_hint"] = ""

    if not profile:
        st.warning("Complete onboarding first.")
        st.session_state.flow_step = "onboarding"
        request_scroll_top()
        st.rerun()
        return

    render_banner(
        "🍳 Guided Session",
        "One page flow: set session goal -> generate lesson -> ask for help -> submit feedback.",
    )
    if not has_openai_key():
        render_missing_key_block()

    st.markdown(
        """
<span class="chef-step">1. Session brief</span>
<span class="chef-step">2. Generate coaching</span>
<span class="chef-step">3. Ask help</span>
<span class="chef-step">4. Submit feedback</span>
""",
        unsafe_allow_html=True,
    )

    curr_state = get_curriculum_state(profile["skill_vector"], profile.get("completed_lessons"), profile=profile)
    lesson = curr_state["next_lesson"]
    if lesson is None:
        st.success("🎉 All available lessons are completed.")
        return

    skill_info = get_skill_info(lesson["skill"])
    m1, m2, m3 = st.columns(3)
    m1.metric("Target Skill", skill_info["name"] if skill_info else lesson["skill"])
    m2.metric("Difficulty", f"Level {lesson['difficulty']}/3")
    m3.metric("Current Mastery", f"{profile['skill_vector'].get(lesson['skill'], 0)*100:.0f}%")

    st.markdown(f"### {lesson['title']}")
    st.caption(f"Objective: {lesson['objective']}")
    st.caption(f"Technique focus: {lesson.get('technique_focus', '')}")

    with st.form("session_brief"):
        c1, c2 = st.columns(2)
        with c1:
            goal = st.text_input(
                "Session goal (optional)",
                value=st.session_state.get("session_goal", ""),
                placeholder="e.g., learn stir-fry timing without burning garlic",
            )
        with c2:
            ingredients_text = st.text_area(
                "Available ingredients (optional, comma-separated)",
                value=st.session_state.get("session_ingredients_text", ""),
                placeholder="e.g., chicken breast, broccoli, garlic, soy sauce",
                height=100,
            )
        generate = st.form_submit_button("Generate Coaching Session", type="primary", width="stretch")

    # Auto-generate exactly once when first entering a lesson with no coaching.
    if st.session_state.get("current_lesson") != lesson and st.session_state.get("current_coaching") is None:
        st.session_state.pending_auto_generate = True

    should_generate = generate or bool(st.session_state.get("pending_auto_generate", False))
    if should_generate:
        auto_started = bool(st.session_state.get("pending_auto_generate", False))
        st.session_state.pending_auto_generate = False
        st.session_state.session_goal = goal
        st.session_state.session_ingredients_text = ingredients_text
        ingredients = parse_ingredients(ingredients_text)

        spinner_text = "Auto-generating your first coaching session..." if auto_started else "Generating personalized coaching..."
        with st.spinner(spinner_text):
            query_parts = [
                lesson["title"],
                lesson["objective"],
                " ".join(lesson.get("practice_recipe_tags", [])),
                goal,
                " ".join(ingredients),
            ]
            query = " ".join(x for x in query_parts if x).strip()
            packets = retrieve_recipes(query, tags_filter=lesson.get("practice_recipe_tags"), n_results=3)
            recipe_context = format_recipe_context(packets, max_recipes=2)
            prev_sessions = get_sessions(st.session_state.user_id, limit=1)
            prev_feedback = prev_sessions[0]["feedback"] if prev_sessions else None

            try:
                coaching = generate_coaching(
                    profile=profile,
                    lesson=lesson,
                    recipe_context=recipe_context,
                    previous_feedback=prev_feedback,
                    session_context={"goal": goal, "ingredients": ingredients},
                )
            except Exception as e:
                st.error(f"Generation failed: {e}")
                coaching = (
                    "### ⚠️ Generation failed\n"
                    "An error occurred while generating coaching. Please check your terminal logs, then try again.\n"
                )

        st.session_state.current_lesson = lesson
        st.session_state.current_coaching = coaching
        st.session_state.session_packets = packets
        st.session_state.help_answer = None
        st.session_state.vision_answer = None
        st.session_state.vision_error = ""
        st.session_state.vision_filename = ""

    if st.session_state.get("current_coaching"):
        st.divider()
        st.markdown("### 🧑‍🍳 Coaching Output")
        st.markdown(st.session_state.current_coaching)
        render_recipe_packets(st.session_state.get("session_packets", []))

        st.divider()
        st.markdown('<div id="chef-help-anchor"></div>', unsafe_allow_html=True)
        st.markdown("### 🆘 I'm Stuck")
        help_q = st.text_input(
            "What happened?",
            key="help_question",
            placeholder="e.g., my onions are burning, sauce too salty",
        )
        if st.button("Ask ChefCoach", key="help_button"):
            if not help_q.strip():
                st.warning("Type a short question first.")
            else:
                with st.spinner("Thinking..."):
                    try:
                        st.session_state.help_answer = answer_help_question(
                            profile,
                            st.session_state.current_lesson,
                            st.session_state.current_coaching,
                            help_q.strip(),
                        )
                        request_scroll_anchor("chef-help-anchor")
                        st.rerun()
                    except Exception as e:
                        st.session_state.help_answer = f"### ⚠️ Help failed\n{e}"
                        request_scroll_anchor("chef-help-anchor")
                        st.rerun()
        if st.session_state.get("help_answer"):
            st.markdown(st.session_state.help_answer)

        st.divider()
        st.markdown('<div id="chef-vision-anchor"></div>', unsafe_allow_html=True)
        st.markdown("### 📷 Identify Ingredient or Tool")
        st.caption("Upload a photo of an unfamiliar ingredient or kitchen tool. This MVP helper currently uses Gemini vision.")
        vision_file = st.file_uploader(
            "Upload image",
            type=["png", "jpg", "jpeg", "webp", "heic", "heif"],
            key="vision_upload",
        )
        vision_bytes = vision_file.getvalue() if vision_file is not None else b""
        vision_ok, vision_validation_error = validate_upload_image(vision_bytes, vision_file.name) if vision_file is not None else (False, "")
        if vision_file is not None:
            if vision_ok:
                st.image(vision_bytes, caption=vision_file.name, width=280)
            elif vision_validation_error:
                st.warning(vision_validation_error)
        st.text_input(
            "Optional note",
            key="vision_hint",
            placeholder="e.g., I found this in my pantry. What is it and how do I use it?",
        )
        vision_provider_ready = get_provider() == "gemini"
        if not vision_provider_ready:
            st.caption("Image identification is available only when LLM_PROVIDER=gemini.")
        if st.button("Identify from Photo", key="vision_button", disabled=not vision_provider_ready):
            if vision_file is None:
                st.session_state.vision_error = "Upload an image first."
                request_scroll_anchor("chef-vision-anchor")
                st.rerun()
            elif not vision_ok:
                st.session_state.vision_error = vision_validation_error or "This file is not a supported image."
                request_scroll_anchor("chef-vision-anchor")
                st.rerun()
            else:
                with st.spinner("Analyzing image..."):
                    try:
                        st.session_state.vision_answer = analyze_image(
                            vision_bytes,
                            mime_type=(vision_file.type or "image/jpeg"),
                            prompt=st.session_state.get("vision_hint", ""),
                        )
                        st.session_state.vision_error = ""
                        st.session_state.vision_filename = vision_file.name
                        request_scroll_anchor("chef-vision-anchor")
                        st.rerun()
                    except LLMError as e:
                        st.session_state.vision_error = f"Image identification failed: {e}"
                        request_scroll_anchor("chef-vision-anchor")
                        st.rerun()
                    except Exception as e:
                        st.session_state.vision_error = f"Image identification failed: {e}"
                        request_scroll_anchor("chef-vision-anchor")
                        st.rerun()
        if st.session_state.get("vision_error"):
            st.error(st.session_state.vision_error)
        if st.session_state.get("vision_answer"):
            if st.session_state.get("vision_filename"):
                st.caption(f"Detected from: {st.session_state['vision_filename']}")
            st.markdown(st.session_state.vision_answer)

        lesson_quiz = st.session_state.current_lesson.get("quiz") if st.session_state.current_lesson else None
        if lesson_quiz:
            st.divider()
            st.markdown("### 🧠 Quick Quiz")
            correct = 0
            for i, q in enumerate(lesson_quiz):
                ans = st.radio(
                    q["q"],
                    options=range(len(q["options"])),
                    format_func=lambda idx, q=q: q["options"][idx],
                    key=f"guided_quiz_{i}",
                )
                if ans == q["answer"]:
                    correct += 1
            total = len(lesson_quiz)
            st.session_state.quiz_score = correct / total if total else 0.5
            st.info(f"Quiz score: {correct}/{total} ({st.session_state.quiz_score*100:.0f}%)")

        st.divider()
        st.markdown("### ✅ Session Feedback")
        with st.form("inline_feedback_form"):
            rating = st.slider("Overall rating", 1, 5, 3)
            difficulty = st.slider("Difficulty", 1, 5, 3, help="1=Too easy, 3=Just right, 5=Too hard")
            completed = st.checkbox("I completed the full recipe", value=True)
            notes = st.text_area("Notes", placeholder="e.g., too bland, pacing was good")
            submit_feedback = st.form_submit_button("Submit Feedback & Save Session", type="primary", width="stretch")

        if submit_feedback:
            active_lesson = st.session_state.current_lesson
            quiz_score = st.session_state.get("quiz_score", 0.5)
            feedback = {
                "rating": rating,
                "difficulty": difficulty,
                "completed": completed,
                "notes": notes,
                "quiz_score": quiz_score,
                "session_goal": st.session_state.get("session_goal", ""),
                "session_ingredients": parse_ingredients(st.session_state.get("session_ingredients_text", "")),
            }
            old_skill = profile["skill_vector"].get(active_lesson["skill"], 0.0)
            updated = update_profile(profile, feedback, active_lesson)
            # Re-cluster learner after each feedback update
            all_sessions = get_sessions(st.session_state.user_id, limit=50)
            feat = build_feature_vector(updated, all_sessions)
            updated["cluster_id"] = assign_cluster(feat)
            save_profile(updated)
            save_session(st.session_state.user_id, active_lesson["id"], st.session_state.current_coaching or "", feedback)
            new_skill = updated["skill_vector"].get(active_lesson["skill"], 0.0)
            delta_pct = (new_skill - old_skill) * 100
            ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            st.session_state.last_saved_at = ts
            push_flash_notice(
                f"Feedback saved. Skill change: {delta_pct:+.1f}%. Session recorded.",
                balloons=True,
                step=3,
            )

            st.session_state.current_lesson = None
            st.session_state.current_coaching = None
            st.session_state.help_answer = None
            st.session_state.vision_answer = None
            st.session_state.vision_error = ""
            st.session_state.vision_filename = ""
            st.session_state["clear_vision_hint"] = True
            st.session_state.session_packets = []
            st.session_state.quiz_score = 0.5
            st.session_state.flow_step = "dashboard"
            request_scroll_top()
            st.rerun()


def render_dashboard(profile: Dict | None) -> None:
    if not profile:
        st.warning("Complete onboarding first.")
        return

    render_banner("📈 Dashboard", "Track skill growth, lesson unlocks, and RAG data footprint.")

    c1, c2, c3, c4 = st.columns(4)
    avg = sum(profile["skill_vector"].values()) / len(profile["skill_vector"]) if profile["skill_vector"] else 0
    c1.metric("Overall Level", f"Lv{profile.get('current_level', 1)}")
    c2.metric("Sessions Completed", profile.get("total_sessions", 0))
    c3.metric("Lessons Done", len(profile.get("completed_lessons", [])))
    c4.metric("Avg Mastery", f"{avg*100:.0f}%")

    st.divider()
    st.markdown("### 🎯 Skill Radar")
    skills = list(profile["skill_vector"].keys())
    values = [profile["skill_vector"][s] for s in skills]
    skills_display = [s.replace("_", " ").title() for s in skills]
    if skills and values:
        skills_display.append(skills_display[0])
        values.append(values[0])
        fig = go.Figure(
            data=go.Scatterpolar(
                r=values,
                theta=skills_display,
                fill="toself",
                line=dict(color="#c96f42", width=3),
                fillcolor="rgba(201,111,66,0.18)",
            )
        )
        fig.update_layout(
            paper_bgcolor="#fbf4ea",
            font=dict(color="#4a2c1f"),
            polar=dict(
                bgcolor="#fbf4ea",
                radialaxis=dict(
                    visible=True,
                    range=[0, 1],
                    gridcolor="rgba(123,90,70,0.18)",
                    linecolor="rgba(123,90,70,0.18)",
                    tickfont=dict(color="#7b5a46"),
                ),
                angularaxis=dict(
                    gridcolor="rgba(123,90,70,0.12)",
                    linecolor="rgba(123,90,70,0.18)",
                    tickfont=dict(color="#4a2c1f"),
                ),
            ),
            height=420,
            margin=dict(l=20, r=20, t=20, b=20),
            showlegend=False,
        )
        st.plotly_chart(fig, width="stretch")

    st.markdown("### 📋 Skill Details")
    curr_state = get_curriculum_state(profile["skill_vector"], profile.get("completed_lessons"), profile=profile)
    for skill in get_all_skills():
        sid = skill["id"]
        val = profile["skill_vector"].get(sid, 0)
        label = "Beginner" if val < 0.3 else ("Intermediate" if val < 0.6 else "Advanced")
        status = "🔓" if sid in curr_state["unlocked_skills"] else "🔒"
        bar_label = html.escape(f"{status} {skill['name']} — {label} ({val*100:.0f}%)")
        fill_pct = max(0.0, min(100.0, val * 100.0))
        c1, c2 = st.columns([3, 1])
        c1.markdown(
            f"""
<div style="margin:0.15rem 0 0.9rem 0;">
  <div style="font-size:0.9rem;color:#f6eddc;margin-bottom:0.32rem;">{bar_label}</div>
  <div style="width:100%;height:0.92rem;background:rgba(232, 206, 178, 0.34);border:1px solid rgba(232, 206, 178, 0.10);border-radius:999px;overflow:hidden;">
    <div style="width:{fill_pct:.1f}%;height:100%;background:linear-gradient(90deg, #efc7a2 0%, #d99163 100%);border-radius:999px;"></div>
  </div>
</div>
""",
            unsafe_allow_html=True,
        )
        c2.caption("No prerequisites" if not skill["prerequisites"] else f"Needs: {', '.join(skill['prerequisites'])}")

    st.divider()
    st.markdown("### 📜 Session Timeline")
    sessions = get_sessions(st.session_state.user_id, limit=50)
    if sessions:
        xs = []
        ys = []
        for s in reversed(sessions):
            ts = s.get("created_at", "")
            try:
                xs.append(datetime.fromisoformat(ts))
            except Exception:
                xs.append(ts)
            fb = s.get("feedback") or {}
            ys.append(fb.get("rating", 0))

        timeline = go.Figure()
        timeline.add_trace(
            go.Scatter(
                x=xs,
                y=ys,
                mode="lines+markers",
                line=dict(color="#c96f42", width=3),
                marker=dict(size=8, color="#8ca07a"),
                name="Rating",
            )
        )
        timeline.update_layout(
            paper_bgcolor="#fbf4ea",
            plot_bgcolor="#fbf4ea",
            font=dict(color="#4a2c1f"),
            height=260,
            margin=dict(l=20, r=20, t=15, b=15),
            yaxis=dict(range=[0, 5], gridcolor="rgba(123,90,70,0.14)", zerolinecolor="rgba(123,90,70,0.16)"),
            xaxis=dict(gridcolor="rgba(123,90,70,0.10)"),
        )
        st.plotly_chart(timeline, width="stretch")

        for s in sessions[:10]:
            with st.expander(f"{s['lesson_id']} — {s['created_at'][:16]}"):
                fb = s.get("feedback") or {}
                st.write(
                    f"Rating: {fb.get('rating', 'N/A')}/5 | "
                    f"Difficulty: {fb.get('difficulty', 'N/A')}/5 | "
                    f"Quiz: {int((fb.get('quiz_score', 0) or 0) * 100)}%"
                )
                if fb.get("notes"):
                    st.caption(f"Notes: {fb['notes']}")
    else:
        st.info("No sessions yet.")

    st.divider()
    st.markdown("### 🗂️ RAG Snapshot")
    summary = load_index_summary()
    if summary:
        s1, s2, s3 = st.columns(3)
        s1.metric("Indexed Recipes", summary.get("total_recipes_indexed", "N/A"))
        s2.metric("Recipes with Ratings", summary.get("recipes_with_rating", "N/A"))
        avg_rating = summary.get("avg_rating_in_indexed_set")
        s3.metric("Avg Indexed Rating", f"{avg_rating:.2f}" if isinstance(avg_rating, (int, float)) else "N/A")
    else:
        st.caption("Run `python setup_rag.py` to generate index summary.")

    if curr_state["next_lesson"]:
        nl = curr_state["next_lesson"]
        st.markdown("### 🔮 Next Recommended Lesson")
        st.markdown(f"**{nl['title']}** ({nl['skill']} - difficulty {nl['difficulty']}/3)")
        st.caption(nl["objective"])
        if st.button("Start Next Guided Session", type="primary", width="stretch"):
            # Force a fresh guided run so user lands back on Generate and auto-runs.
            st.session_state.current_lesson = None
            st.session_state.current_coaching = None
            st.session_state.help_answer = None
            st.session_state.vision_answer = None
            st.session_state.vision_error = ""
            st.session_state.vision_filename = ""
            st.session_state["clear_vision_hint"] = True
            st.session_state.session_packets = []
            st.session_state.quiz_score = 0.5
            st.session_state.session_goal = ""
            st.session_state.session_ingredients_text = ""
            st.session_state.flow_step = "guided"
            st.session_state.pending_auto_generate = True
            request_scroll_top()
            st.rerun()


def main() -> None:
    apply_theme()
    ensure_state()
    st.markdown('<div id="chef-top-anchor"></div>', unsafe_allow_html=True)
    profile = get_profile(st.session_state.user_id)
    flow_step = st.session_state.get("flow_step", "onboarding")
    if not profile:
        flow_step = "onboarding"
    elif flow_step == "onboarding":
        flow_step = "guided"
    if flow_step not in {"onboarding", "guided", "dashboard"}:
        flow_step = "guided"
    st.session_state.flow_step = flow_step
    render_sidebar_progress(profile, flow_step)
    render_flash_notice()

    if flow_step == "onboarding":
        render_onboarding(profile)
    elif flow_step == "guided":
        render_guided_session(profile)
    elif flow_step == "dashboard":
        render_dashboard(profile)

    # Execute after page content renders, so anchor/container exists.
    maybe_scroll_top()


if __name__ == "__main__":
    main()
