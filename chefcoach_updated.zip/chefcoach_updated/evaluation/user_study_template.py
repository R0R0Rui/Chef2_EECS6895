"""
Evaluation D: Small User Study (Optional)
Generates a survey template for 5-10 users doing 2-3 sessions.
Collects: perceived learning improvement, satisfaction, "would cook again" rate.
"""

import json
import os


SURVEY_TEMPLATE = {
    "title": "ChefCoach User Study",
    "description": "Complete 2-3 cooking sessions with ChefCoach, then answer these questions.",
    "pre_session": {
        "instructions": "Answer these BEFORE your first session.",
        "questions": [
            {"id": "pre_1", "type": "scale_1_5", "text": "How confident are you in your cooking skills overall?"},
            {"id": "pre_2", "type": "scale_1_5", "text": "How often do you cook per week?"},
            {"id": "pre_3", "type": "open", "text": "What cooking skill would you most like to improve?"},
            {"id": "pre_4", "type": "scale_1_5", "text": "How comfortable are you following new recipes?"}
        ]
    },
    "per_session": {
        "instructions": "Answer these AFTER each session.",
        "questions": [
            {"id": "ses_1", "type": "scale_1_5", "text": "How helpful was this coaching session?"},
            {"id": "ses_2", "type": "scale_1_5", "text": "Was the difficulty level appropriate?"},
            {"id": "ses_3", "type": "scale_1_5", "text": "Did you learn something new?"},
            {"id": "ses_4", "type": "yes_no", "text": "Would you cook this recipe again?"},
            {"id": "ses_5", "type": "open", "text": "What was most helpful? What would you improve?"}
        ]
    },
    "post_study": {
        "instructions": "Answer these AFTER all sessions are complete.",
        "questions": [
            {"id": "post_1", "type": "scale_1_5", "text": "How much did your cooking skills improve?"},
            {"id": "post_2", "type": "scale_1_5", "text": "How personalized did the coaching feel?"},
            {"id": "post_3", "type": "scale_1_5", "text": "Did later sessions feel better adapted to you than earlier ones?"},
            {"id": "post_4", "type": "yes_no", "text": "Would you recommend ChefCoach to a friend?"},
            {"id": "post_5", "type": "scale_1_5", "text": "Overall satisfaction with ChefCoach (1=poor, 5=excellent)"},
            {"id": "post_6", "type": "open", "text": "Any additional feedback or suggestions?"}
        ]
    },
    "metrics_to_compute": [
        "Average perceived learning improvement (post_1)",
        "Average personalization rating (post_2)",
        "Adaptation detection rate (post_3 >= 4)",
        "Recommendation rate (post_4 = yes)",
        "Overall satisfaction (post_5)",
        "Would cook again rate across sessions (ses_4 = yes)"
    ]
}


def generate_study_template():
    """Generate the user study template and save it."""
    output_dir = os.path.join("evaluation", "results")
    os.makedirs(output_dir, exist_ok=True)

    output_path = os.path.join(output_dir, "user_study_template.json")
    with open(output_path, "w") as f:
        json.dump(SURVEY_TEMPLATE, f, indent=2)

    print(f"  User study template saved to: {output_path}")
    print(f"  Pre-session questions: {len(SURVEY_TEMPLATE['pre_session']['questions'])}")
    print(f"  Per-session questions: {len(SURVEY_TEMPLATE['per_session']['questions'])}")
    print(f"  Post-study questions: {len(SURVEY_TEMPLATE['post_study']['questions'])}")
    print(f"  Metrics to compute: {len(SURVEY_TEMPLATE['metrics_to_compute'])}")

    return {
        "template_path": output_path,
        "total_questions": (
            len(SURVEY_TEMPLATE["pre_session"]["questions"]) +
            len(SURVEY_TEMPLATE["per_session"]["questions"]) +
            len(SURVEY_TEMPLATE["post_study"]["questions"])
        ),
        "recommended_participants": "5-10 users",
        "recommended_sessions": "2-3 sessions per user",
        "status": "template_generated"
    }
