"""
Evaluation C: Grounding / Hallucination Spot Check

Runs real generation against retrieved packets, then checks:
- expected concept coverage
- lexical grounding overlap with retrieved context
- safety keyword coverage for risky topics
"""

from __future__ import annotations

import os
import re
import sys
from collections import Counter
from typing import Dict, List, Tuple

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from modules.coach_generator import generate_baseline_coaching
from modules.rag_retriever import retrieve_recipes, format_recipe_context


SAFETY_KEYWORDS = {
    "knife": ["safety", "grip", "careful", "finger", "away from body"],
    "heat": ["hot", "burn", "careful", "temperature", "safety"],
    "oil": ["splatter", "water", "careful", "hot"],
    "oven": ["mitts", "hot", "temperature", "careful"],
    "raw": ["temperature", "safe", "cook through", "internal temp"],
}

STOPWORDS = {
    "with", "from", "this", "that", "have", "your", "when", "what", "where", "which",
    "into", "then", "than", "will", "just", "very", "more", "less", "also", "about",
    "using", "recipe", "packet", "packets", "lesson", "step", "steps", "cook", "cooking",
}

GROUNDING_TESTS = [
    {
        "query": "knife safety cutting vegetables claw grip",
        "tags": ["cutting", "knife", "salad"],
        "expected_elements": ["knife", "cut", "grip"],
        "safety_topic": "knife",
        "lesson": {"title": "Knife Safety Drill", "objective": "Practice safe cutting form."},
    },
    {
        "query": "heat control searing pan fry temperature",
        "tags": ["sear", "heat", "pan fry"],
        "expected_elements": ["heat", "pan", "temperature"],
        "safety_topic": "heat",
        "lesson": {"title": "Heat Control Drill", "objective": "Read pan temperature and sear cleanly."},
    },
    {
        "query": "seasoning salt layering flavor balance",
        "tags": ["seasoning", "salt", "flavor"],
        "expected_elements": ["salt", "season", "taste"],
        "safety_topic": None,
        "lesson": {"title": "Seasoning Drill", "objective": "Layer seasoning and rebalance flavor."},
    },
    {
        "query": "stir fry wok high heat vegetables",
        "tags": ["stir fry", "wok", "vegetables"],
        "expected_elements": ["stir", "heat", "vegetable"],
        "safety_topic": "oil",
        "lesson": {"title": "Stir-Fry Drill", "objective": "Control high heat wok sequencing."},
    },
    {
        "query": "baking cookies oven temperature measuring",
        "tags": ["cookies", "baking", "oven"],
        "expected_elements": ["bak", "oven", "temperature"],
        "safety_topic": "oven",
        "lesson": {"title": "Baking Drill", "objective": "Measure accurately and manage oven heat."},
    },
]


def _tokenize(text: str) -> List[str]:
    return [t for t in re.findall(r"[a-zA-Z]+", text.lower()) if len(t) >= 4 and t not in STOPWORDS]


def _top_context_keywords(recipe_context: str, max_k: int = 30) -> List[str]:
    counts = Counter(_tokenize(recipe_context))
    return [w for w, _ in counts.most_common(max_k)]


def check_grounding(coaching_text: str, recipe_context: str, expected_elements: List[str]) -> Tuple[float, List[str]]:
    """
    Returns: (grounding_score, issues)
    Score mixes expected-element coverage + lexical overlap with retrieved context.
    """
    coaching_lower = coaching_text.lower()
    issues: List[str] = []

    expected_hit = 0
    for element in expected_elements:
        if element.lower() in coaching_lower:
            expected_hit += 1
        else:
            issues.append(f"Missing expected element: '{element}'")
    expected_score = expected_hit / len(expected_elements) if expected_elements else 1.0

    context_keywords = _top_context_keywords(recipe_context, max_k=25)
    overlap_hit = sum(1 for kw in context_keywords if kw in coaching_lower)
    overlap_score = overlap_hit / len(context_keywords) if context_keywords else 1.0
    if overlap_score < 0.2:
        issues.append("Low lexical overlap with retrieved packets (possible weak grounding).")

    # Blend expected concepts (primary) + context overlap (secondary)
    score = 0.7 * expected_score + 0.3 * overlap_score
    return score, issues


def check_safety(coaching_text: str, safety_topic: str | None) -> Tuple[bool, List[str]]:
    if safety_topic is None:
        return True, []

    coaching_lower = coaching_text.lower()
    keywords = SAFETY_KEYWORDS.get(safety_topic, [])
    found = sum(1 for kw in keywords if kw in coaching_lower)

    if found == 0:
        return False, [f"No safety keywords found for topic '{safety_topic}'"]
    return True, []


def _generate_for_eval(test: Dict, recipe_context: str) -> str:
    lesson = {
        "title": test["lesson"]["title"],
        "objective": test["lesson"]["objective"],
    }
    return generate_baseline_coaching(lesson, recipe_context)


def run_grounding_check():
    results = {"tests": [], "summary": {}}
    total_grounding_score = 0.0
    total_safety_pass = 0
    total_safety_checks = 0
    all_issues: List[str] = []

    for test in GROUNDING_TESTS:
        print(f"  Checking: {test['query'][:50]}...")

        recipes = retrieve_recipes(test["query"], tags_filter=test["tags"], n_results=3)
        recipe_context = format_recipe_context(recipes)
        if not recipe_context.strip():
            test_result = {
                "query": test["query"],
                "recipes_found": 0,
                "grounding_score": 0.0,
                "safety_pass": False if test["safety_topic"] else True,
                "issues": ["No recipes retrieved for grounding check."],
            }
            results["tests"].append(test_result)
            all_issues.extend(test_result["issues"])
            print("    ⚠️ No retrieved context; skipping generation.")
            continue

        try:
            coaching_text = _generate_for_eval(test, recipe_context)
        except Exception as e:
            coaching_text = ""
            all_issues.append(f"Generation error for '{test['query']}': {e}")

        grounding_score, g_issues = check_grounding(
            coaching_text=coaching_text,
            recipe_context=recipe_context,
            expected_elements=test["expected_elements"],
        )
        total_grounding_score += grounding_score

        if test["safety_topic"]:
            total_safety_checks += 1
            safety_pass, s_issues = check_safety(coaching_text, test["safety_topic"])
            if safety_pass:
                total_safety_pass += 1
        else:
            safety_pass, s_issues = True, []

        issues = g_issues + s_issues
        all_issues.extend(issues)
        results["tests"].append(
            {
                "query": test["query"],
                "recipes_found": len(recipes),
                "grounding_score": round(grounding_score, 4),
                "safety_pass": safety_pass,
                "issues": issues,
            }
        )

        status = "✅" if grounding_score >= 0.6 and safety_pass else "⚠️"
        print(
            f"    {status} Grounding: {grounding_score:.2f}, "
            f"Safety: {'PASS' if safety_pass else 'FAIL'}"
        )

    n = len(results["tests"]) if results["tests"] else 1
    results["summary"] = {
        "total_tests": len(results["tests"]),
        "avg_grounding_score": round(total_grounding_score / n, 4),
        "safety_pass_rate": round(total_safety_pass / total_safety_checks, 4) if total_safety_checks else 1.0,
        "total_issues": len(all_issues),
        "issues": all_issues[:15],
    }

    print(
        f"\n  RESULTS: Avg grounding score: {results['summary']['avg_grounding_score']:.2f}, "
        f"Safety pass rate: {results['summary']['safety_pass_rate']*100:.0f}%"
    )
    return results


if __name__ == "__main__":
    run_grounding_check()
