"""llm_judge.py — Evaluation A (proposal)

Pairwise LLM-as-Judge evaluation.

We compare 3 systems on the same scenarios:
1) Baseline-1: No memory (single-turn generic coach)
2) Baseline-2: Memory but *no feedback memory* (profile only)
3) ChefCoach: Full system (profile + feedback-updated profile + feedback memory)

The ChefCoach path simulates a real 2-session learning loop:
  - Start with the base profile
  - Apply update_profile(profile, previous_feedback, lesson) to update
    skill_vector, taste_prefs, confidence, and XP (just like the real app)
  - Then generate coaching with the *updated* profile + previous_feedback

This ensures Evaluation A tests the actual learning mechanism, not merely
injecting a feedback paragraph into the prompt.

Rubric (1-5 each):
- personalization
- difficulty
- clarity
- safety
- teaching

Output:
- win-rate of ChefCoach vs each baseline
- average rubric scores
- configurable multi-scenario benchmark (default: 24)

NOTE: This evaluation calls an online LLM for judging (and optionally for
output generation). To run offline, set LLM_PROVIDER=mock.

Fair-comparison mode:
- Keep generation provider as-is (offline or online),
- but pin judge provider/model via JUDGE_* env vars.
This keeps metric A on a single judging scale across runs.
"""

from __future__ import annotations

import json
import os
import sys
import copy
from contextlib import contextmanager
from typing import Any, Dict, Iterator, List, Optional

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from modules.llm_client import ChatMessage, chat, extract_first_json
from modules.coach_generator import generate_baseline_coaching, generate_coaching
from modules.feedback_updater import update_profile
from modules.rag_retriever import retrieve_recipes, format_recipe_context


JUDGE_SYSTEM = """You are an expert evaluator of cooking education.
You will compare two coaching outputs for the same learner profile and lesson.

Rate each output on these 5 dimensions (1-5 scale):
1. Personalization Fit
2. Difficulty Match
3. Instruction Clarity
4. Food Safety
5. Teaching Value (explains WHY, not just WHAT)

Output ONLY valid JSON:
{
  "output_a_scores": {"personalization": X, "difficulty": X, "clarity": X, "safety": X, "teaching": X},
  "output_b_scores": {"personalization": X, "difficulty": X, "clarity": X, "safety": X, "teaching": X},
  "winner": "A" | "B" | "tie",
  "reasoning": "Brief explanation (1-3 sentences)"
}
"""


DEFAULT_SCENARIO_LIMIT = 24

# 3 learner levels x 8 feedback variants = 24 scenarios (default full run).
PERSONA_BLUEPRINTS: List[Dict[str, Any]] = [
    {
        "label": "Beginner",
        "profile": {
            "name": "Alex",
            "experience_level": "beginner",
            "current_level": 1,
            "skill_vector": {"knife_safety": 0.1, "heat_control": 0.1, "seasoning": 0.1},
            "taste_prefs": {"spicy": 0.2, "sweet": 0.5, "sour": 0.5, "salty": 0.5, "umami": 0.5},
            "constraints": {"dietary": ["vegetarian"], "allergies": [], "equipment": ["stove"], "time_budget_minutes": 20},
            "completed_lessons": [],
        },
        "lesson": {
            "title": "Seasoning 101: Salt Layering",
            "skill": "seasoning",
            "difficulty": 1,
            "objective": "Learn to season at each stage and taste as you go.",
            "technique_focus": "Layering salt and tasting to avoid under/over-seasoning.",
            "common_mistakes": ["Salting only at the end", "Not tasting", "Using too much at once"],
            "safety_notes": [],
        },
        "base_rag_query": "quick vegetarian soup seasoning salt tasting",
        "base_rag_tags": ["vegetarian", "soup", "seasoning"],
    },
    {
        "label": "Intermediate",
        "profile": {
            "name": "Sam",
            "experience_level": "intermediate",
            "current_level": 3,
            "skill_vector": {"knife_safety": 0.5, "heat_control": 0.4, "stir_fry": 0.3, "seasoning": 0.2},
            "taste_prefs": {"spicy": 0.8, "sweet": 0.4, "sour": 0.4, "salty": 0.5, "umami": 0.6},
            "constraints": {"dietary": [], "allergies": [], "equipment": ["stove", "wok"], "time_budget_minutes": 35},
            "completed_lessons": ["knife_101"],
        },
        "lesson": {
            "title": "Stir-Fry Basics",
            "skill": "stir_fry",
            "difficulty": 2,
            "objective": "Practice high-heat stir-fry sequencing and timing.",
            "technique_focus": "Prep first, then cook fast over high heat.",
            "common_mistakes": ["Overcrowding the pan", "Adding sauce too early"],
            "safety_notes": ["Hot oil can splatter"],
        },
        "base_rag_query": "stir fry chicken vegetables wok high heat",
        "base_rag_tags": ["stir fry", "wok", "vegetables"],
    },
    {
        "label": "Advanced",
        "profile": {
            "name": "Jordan",
            "experience_level": "advanced",
            "current_level": 4,
            "skill_vector": {"knife_safety": 0.7, "heat_control": 0.6, "timing": 0.3, "sauce": 0.2},
            "taste_prefs": {"spicy": 0.5, "sweet": 0.4, "sour": 0.5, "salty": 0.5, "umami": 0.7},
            "constraints": {"dietary": [], "allergies": [], "equipment": ["stove", "oven"], "time_budget_minutes": 60},
            "completed_lessons": ["knife_101", "heat_101"],
        },
        "lesson": {
            "title": "Timing a 2-Component Meal",
            "skill": "timing",
            "difficulty": 2,
            "objective": "Coordinate two components so they finish together.",
            "technique_focus": "Backward planning and holding techniques.",
            "common_mistakes": ["Starting everything at once", "Not using a timer"],
            "safety_notes": [],
        },
        "base_rag_query": "sheet pan chicken vegetables timing oven",
        "base_rag_tags": ["oven", "sheet pan"],
    },
]

FEEDBACK_VARIANTS: List[Dict[str, Any]] = [
    {
        "label": "bland food",
        "previous_feedback": {"rating": 3, "difficulty": 3, "notes": "Too bland, I only tasted at the end.", "quiz_score": 0.5},
        "rag_hint": "seasoning layering salt tasting",
        "rag_tags": ["seasoning"],
    },
    {
        "label": "too spicy",
        "previous_feedback": {"rating": 3, "difficulty": 3, "notes": "Too spicy for me and hard to balance.", "quiz_score": 0.6},
        "rag_hint": "reduce spice balance sweetness acidity",
        "rag_tags": ["seasoning"],
    },
    {
        "label": "unclear instructions",
        "previous_feedback": {"rating": 2, "difficulty": 4, "notes": "Instructions were too fast and confusing.", "quiz_score": 0.4},
        "rag_hint": "step by step pacing beginner clarity",
        "rag_tags": ["beginner", "timing"],
    },
    {
        "label": "timing issue",
        "previous_feedback": {"rating": 3, "difficulty": 3, "notes": "One component finished too early and got cold.", "quiz_score": 0.6},
        "rag_hint": "meal timing sequencing hold warm",
        "rag_tags": ["timing"],
    },
    {
        "label": "safety concern",
        "previous_feedback": {"rating": 2, "difficulty": 4, "notes": "I undercooked part of the dish and felt unsafe.", "quiz_score": 0.4},
        "rag_hint": "safe temperature doneness food safety",
        "rag_tags": ["safety", "heat_control"],
    },
    {
        "label": "equipment mismatch",
        "previous_feedback": {"rating": 3, "difficulty": 4, "notes": "I did not have the right pan and got stuck.", "quiz_score": 0.5},
        "rag_hint": "equipment alternatives substitutions stovetop",
        "rag_tags": ["equipment", "substitutions"],
    },
    {
        "label": "too easy",
        "previous_feedback": {"rating": 3, "difficulty": 1, "notes": "This session was too easy and repetitive.", "quiz_score": 0.95},
        "rag_hint": "increase challenge advanced variation",
        "rag_tags": ["advanced", "progression"],
    },
    {
        "label": "too hard",
        "previous_feedback": {"rating": 2, "difficulty": 5, "notes": "The pace and technique difficulty were too high for me.", "quiz_score": 0.3},
        "rag_hint": "simplify steps beginner-friendly pacing",
        "rag_tags": ["beginner", "pacing"],
    },
]


def _merge_tags(a: List[str], b: List[str]) -> List[str]:
    out: List[str] = []
    seen = set()
    for x in (a or []) + (b or []):
        if x not in seen:
            seen.add(x)
            out.append(x)
    return out


def _scenario_limit() -> int:
    raw = os.getenv("EVAL_A_SCENARIO_LIMIT", str(DEFAULT_SCENARIO_LIMIT)).strip()
    try:
        n = int(raw)
    except ValueError:
        return DEFAULT_SCENARIO_LIMIT
    return max(1, n)


def _build_scenarios() -> List[Dict[str, Any]]:
    scenarios: List[Dict[str, Any]] = []
    for persona in PERSONA_BLUEPRINTS:
        for fb in FEEDBACK_VARIANTS:
            scenarios.append(
                {
                    "name": f"{persona['label']} + {fb['label']}",
                    "profile": copy.deepcopy(persona["profile"]),
                    "lesson": copy.deepcopy(persona["lesson"]),
                    "previous_feedback": copy.deepcopy(fb["previous_feedback"]),
                    "rag_query": f"{persona['base_rag_query']} {fb['rag_hint']}".strip(),
                    "rag_tags": _merge_tags(persona["base_rag_tags"], fb["rag_tags"]),
                }
            )

    limit = _scenario_limit()
    return scenarios[:limit]


@contextmanager
def _temporary_env(overrides: Dict[str, Optional[str]]) -> Iterator[None]:
    """Temporarily override environment variables for one API call."""
    old_values: Dict[str, Optional[str]] = {}
    for key, value in overrides.items():
        old_values[key] = os.environ.get(key)
        if value is None:
            os.environ.pop(key, None)
        else:
            os.environ[key] = value
    try:
        yield
    finally:
        for key, old_value in old_values.items():
            if old_value is None:
                os.environ.pop(key, None)
            else:
                os.environ[key] = old_value


def _judge_provider() -> str:
    provider = os.getenv("JUDGE_PROVIDER", os.getenv("LLM_PROVIDER", "gemini")).strip().lower()
    if provider not in {"gemini", "openai", "mock"}:
        raise ValueError(f"Unsupported JUDGE_PROVIDER: {provider}")
    return provider


def _judge_env_overrides() -> Dict[str, Optional[str]]:
    provider = _judge_provider()
    overrides: Dict[str, Optional[str]] = {"LLM_PROVIDER": provider}

    if provider == "gemini":
        overrides["GEMINI_MODEL"] = os.getenv(
            "JUDGE_GEMINI_MODEL",
            os.getenv("GEMINI_MODEL", "gemini-2.5-flash-lite"),
        ).strip()
        # If JUDGE_GEMINI_API_KEY is missing, fallback to app key.
        overrides["GEMINI_API_KEY"] = os.getenv(
            "JUDGE_GEMINI_API_KEY",
            os.getenv("GEMINI_API_KEY", ""),
        ).strip() or None
        return overrides

    if provider == "openai":
        overrides["OPENAI_API_BASE"] = os.getenv(
            "JUDGE_OPENAI_API_BASE",
            os.getenv("OPENAI_API_BASE", "https://api.openai.com/v1"),
        ).strip()
        overrides["OPENAI_API_KEY"] = os.getenv(
            "JUDGE_OPENAI_API_KEY",
            os.getenv("OPENAI_API_KEY", ""),
        ).strip() or None
        overrides["MODEL_NAME"] = os.getenv(
            "JUDGE_MODEL_NAME",
            os.getenv("MODEL_NAME", "gpt-4o-mini"),
        ).strip()
        return overrides

    return overrides


def _judge_config_summary() -> str:
    provider = _judge_provider()
    if provider == "gemini":
        model = os.getenv("JUDGE_GEMINI_MODEL", os.getenv("GEMINI_MODEL", "gemini-2.5-flash-lite")).strip()
        return f"provider={provider}, model={model}"
    if provider == "openai":
        model = os.getenv("JUDGE_MODEL_NAME", os.getenv("MODEL_NAME", "gpt-4o-mini")).strip()
        base = os.getenv("JUDGE_OPENAI_API_BASE", os.getenv("OPENAI_API_BASE", "https://api.openai.com/v1")).strip()
        return f"provider={provider}, model={model}, base={base}"
    return "provider=mock"


def _judge_chat(
    messages: List[ChatMessage],
    *,
    temperature: float,
    max_tokens: int,
    expect_json: bool,
) -> str:
    with _temporary_env(_judge_env_overrides()):
        return chat(
            messages,
            temperature=temperature,
            max_tokens=max_tokens,
            expect_json=expect_json,
        )


def _judge_pair(profile: Dict[str, Any], lesson: Dict[str, Any], output_a: str, output_b: str) -> Dict[str, Any]:
    user_prompt = f"""LEARNER PROFILE (JSON):\n{json.dumps(profile)}\n\nLESSON (JSON):\n{json.dumps(lesson)}\n\nOUTPUT A:\n{output_a}\n\nOUTPUT B:\n{output_b}\n"""

    raw = _judge_chat(
        [
            ChatMessage(role="system", content=JUDGE_SYSTEM),
            ChatMessage(role="user", content=user_prompt),
        ],
        temperature=0.2,
        max_tokens=700,
        expect_json=True,
    )

    try:
        return extract_first_json(raw)
    except Exception:
        # Local judges can occasionally return prose even with JSON instructions.
        # Ask once more as a strict "JSON repair" pass.
        repair_system = """Convert the given text into valid JSON only.
Return one JSON object matching exactly this schema:
{
  "output_a_scores": {"personalization": 1-5, "difficulty": 1-5, "clarity": 1-5, "safety": 1-5, "teaching": 1-5},
  "output_b_scores": {"personalization": 1-5, "difficulty": 1-5, "clarity": 1-5, "safety": 1-5, "teaching": 1-5},
  "winner": "A" | "B" | "tie",
  "reasoning": "1-3 sentences"
}
No markdown, no explanation, JSON only."""

        repaired = _judge_chat(
            [
                ChatMessage(role="system", content=repair_system),
                ChatMessage(role="user", content=raw or user_prompt),
            ],
            temperature=0.0,
            max_tokens=500,
            expect_json=True,
        )
        return extract_first_json(repaired)


def _fallback_tie_judgement(reason: str) -> Dict[str, Any]:
    return {
        "output_a_scores": {"personalization": 3, "difficulty": 3, "clarity": 3, "safety": 3, "teaching": 3},
        "output_b_scores": {"personalization": 3, "difficulty": 3, "clarity": 3, "safety": 3, "teaching": 3},
        "winner": "tie",
        "reasoning": f"Judge parsing fallback: {reason}",
    }


def _coerce_score(raw: Any) -> float:
    try:
        value = float(raw)
    except Exception:
        return 3.0
    return min(5.0, max(1.0, value))


def _normalize_scores(raw_scores: Dict[str, Any]) -> Dict[str, float]:
    # Some judges may use "stimulation" instead of "teaching".
    teaching_raw = raw_scores.get("teaching", raw_scores.get("stimulation", 3))
    return {
        "personalization": _coerce_score(raw_scores.get("personalization", 3)),
        "difficulty": _coerce_score(raw_scores.get("difficulty", 3)),
        "clarity": _coerce_score(raw_scores.get("clarity", 3)),
        "safety": _coerce_score(raw_scores.get("safety", 3)),
        "teaching": _coerce_score(teaching_raw),
    }


def _normalize_judge_result(raw: Dict[str, Any]) -> Dict[str, Any]:
    if not isinstance(raw, dict):
        raise ValueError("Judge output is not a JSON object.")

    a_scores = _normalize_scores(raw.get("output_a_scores", {}))
    b_scores = _normalize_scores(raw.get("output_b_scores", {}))

    winner = str(raw.get("winner", "")).strip().lower()
    if winner not in {"a", "b", "tie"}:
        a_total = sum(a_scores.values())
        b_total = sum(b_scores.values())
        if abs(a_total - b_total) < 0.5:
            winner = "tie"
        else:
            winner = "a" if a_total > b_total else "b"

    reasoning = str(raw.get("reasoning", "")).strip()
    if not reasoning:
        reasoning = "Auto-completed winner from normalized rubric totals."

    return {
        "output_a_scores": a_scores,
        "output_b_scores": b_scores,
        "winner": winner.upper() if winner in {"a", "b"} else "tie",
        "reasoning": reasoning,
    }


def run_judge_evaluation() -> Dict[str, Any]:
    results: Dict[str, Any] = {"scenarios": [], "summary": {}}
    scenarios = _build_scenarios()

    chefcoach_wins_vs_baseline = 0
    chefcoach_wins_vs_memory = 0
    print(f"Judge config: {_judge_config_summary()}")
    print(f"Scenario count: {len(scenarios)} (set EVAL_A_SCENARIO_LIMIT to change)")

    for sc in scenarios:
        print(f"Evaluating: {sc['name']} ...")

        packets = retrieve_recipes(sc["rag_query"], tags_filter=sc.get("rag_tags"), n_results=3)
        recipe_context = format_recipe_context(packets, max_recipes=3)

        # --- System 1: Baseline (no memory, no profile) ---
        baseline = generate_baseline_coaching(sc["lesson"], recipe_context)

        # --- System 2: Memory-only (profile but no feedback learning) ---
        memory_only = generate_coaching(sc["profile"], sc["lesson"], recipe_context, previous_feedback=None)

        # --- System 3: ChefCoach (full learning loop) ---
        # Simulate the real 2-session learning cycle:
        # 1. Apply update_profile with previous_feedback to update skill_vector,
        #    taste_prefs, confidence, and XP — exactly as the live app does.
        # 2. Generate coaching with the *updated* profile + feedback context.
        chefcoach_profile = copy.deepcopy(sc["profile"])
        prev_fb = sc.get("previous_feedback")
        if prev_fb:
            # Build a minimal lesson dict for update_profile (needs "skill" and "id")
            update_lesson = copy.deepcopy(sc["lesson"])
            update_lesson.setdefault("id", update_lesson.get("title", "eval_lesson"))
            update_profile(chefcoach_profile, prev_fb, update_lesson)

        chefcoach = generate_coaching(chefcoach_profile, sc["lesson"], recipe_context, previous_feedback=prev_fb)

        # Judge: Baseline (A) vs ChefCoach (B)
        try:
            j1 = _normalize_judge_result(_judge_pair(chefcoach_profile, sc["lesson"], baseline, chefcoach))
        except Exception as e:
            print(f"  Warning: judge failed on baseline_vs_chefcoach ({sc['name']}): {e}")
            j1 = _fallback_tie_judgement(str(e))
        if j1.get("winner") == "B":
            chefcoach_wins_vs_baseline += 1

        # Judge: Memory-only (A) vs ChefCoach (B)
        try:
            j2 = _normalize_judge_result(_judge_pair(chefcoach_profile, sc["lesson"], memory_only, chefcoach))
        except Exception as e:
            print(f"  Warning: judge failed on memory_only_vs_chefcoach ({sc['name']}): {e}")
            j2 = _fallback_tie_judgement(str(e))
        if j2.get("winner") == "B":
            chefcoach_wins_vs_memory += 1

        results["scenarios"].append(
            {
                "name": sc["name"],
                "baseline_vs_chefcoach": j1,
                "memory_only_vs_chefcoach": j2,
            }
        )

    n = len(scenarios)
    results["summary"] = {
        "total_scenarios": n,
        "chefcoach_win_rate_vs_baseline": chefcoach_wins_vs_baseline / n if n else 0.0,
        "chefcoach_win_rate_vs_memory_only": chefcoach_wins_vs_memory / n if n else 0.0,
    }

    print("\n=== Summary ===")
    print(f"ChefCoach vs Baseline win-rate: {results['summary']['chefcoach_win_rate_vs_baseline']*100:.0f}%")
    print(f"ChefCoach vs Memory-only win-rate: {results['summary']['chefcoach_win_rate_vs_memory_only']*100:.0f}%")

    return results


if __name__ == "__main__":
    out = run_judge_evaluation()
    os.makedirs("evaluation/results", exist_ok=True)
    with open("evaluation/results/llm_judge_results.json", "w", encoding="utf-8") as f:
        json.dump(out, f, indent=2)
    print("Saved to evaluation/results/llm_judge_results.json")
