"""
run_eval.py — Run all 4 evaluation methods for ChefCoach
Usage: python evaluation/run_eval.py

Evaluations:
A. Pairwise LLM-as-Judge (ChefCoach vs baselines)
B. Curriculum Progression Test (skill unlocking sanity check)
C. Grounding / Hallucination Spot Check
D. User Study Template (optional, generates survey)
"""

import sys
import os
import json
from datetime import datetime

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from dotenv import load_dotenv
load_dotenv()


def run_all():
    print("=" * 70)
    print("ChefCoach Evaluation Suite")
    print(f"Run at: {datetime.now().isoformat()}")
    print("=" * 70)

    results = {}

    # A. LLM-as-Judge
    print("\n" + "=" * 70)
    print("A. Pairwise LLM-as-Judge Evaluation")
    print("=" * 70)
    try:
        from evaluation.llm_judge import run_judge_evaluation
        results["A_llm_judge"] = run_judge_evaluation()
    except Exception as e:
        print(f"  Error: {e}")
        results["A_llm_judge"] = {"error": str(e)}

    # B. Curriculum Progression Test
    print("\n" + "=" * 70)
    print("B. Curriculum Progression Test")
    print("=" * 70)
    try:
        from evaluation.curriculum_test import run_curriculum_test
        results["B_curriculum"] = run_curriculum_test()
    except Exception as e:
        print(f"  Error: {e}")
        results["B_curriculum"] = {"error": str(e)}

    # C. Grounding Check
    print("\n" + "=" * 70)
    print("C. Grounding / Hallucination Spot Check")
    print("=" * 70)
    try:
        from evaluation.grounding_check import run_grounding_check
        results["C_grounding"] = run_grounding_check()
    except Exception as e:
        print(f"  Error: {e}")
        results["C_grounding"] = {"error": str(e)}

    # D. User Study Template
    print("\n" + "=" * 70)
    print("D. User Study (Template Generated)")
    print("=" * 70)
    try:
        from evaluation.user_study_template import generate_study_template
        results["D_user_study"] = generate_study_template()
    except Exception as e:
        print(f"  Error: {e}")
        results["D_user_study"] = {"error": str(e)}

    # Save results
    os.makedirs("evaluation/results", exist_ok=True)
    output_path = f"evaluation/results/eval_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
    with open(output_path, "w") as f:
        json.dump(results, f, indent=2, default=str)

    print(f"\n{'=' * 70}")
    print(f"All evaluations complete. Results saved to: {output_path}")
    print(f"{'=' * 70}")

    return results


if __name__ == "__main__":
    run_all()
