"""
Evaluation B: Curriculum Progression Test
Simulates 3-session learning trajectories for multiple personas.
Measures: does the system unlock appropriate lessons when skill > threshold?
"""

import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from modules.curriculum_planner import (
    select_lesson, get_unlocked_skills, get_locked_skills, get_all_skills
)
from modules.feedback_updater import update_profile


# Simulated personas with different starting points
PERSONAS = [
    {
        "name": "Complete Novice",
        "skill_vector": {
            "knife_safety": 0.1, "heat_control": 0.0, "seasoning": 0.0,
            "stir_fry": 0.0, "baking_basics": 0.0, "timing": 0.0,
            "sauce": 0.0, "plating": 0.0
        },
        "expected_first_skill": "knife_safety",
        "sessions": [
            {"rating": 4, "difficulty": 3, "completed": True, "quiz_score": 0.7, "notes": ""},
            {"rating": 5, "difficulty": 2, "completed": True, "quiz_score": 0.9, "notes": ""},
            {"rating": 4, "difficulty": 3, "completed": True, "quiz_score": 0.8, "notes": ""},
        ]
    },
    {
        "name": "Home Cook",
        "skill_vector": {
            "knife_safety": 0.5, "heat_control": 0.4, "seasoning": 0.2,
            "stir_fry": 0.1, "baking_basics": 0.1, "timing": 0.0,
            "sauce": 0.0, "plating": 0.0
        },
        "expected_first_skill": "stir_fry",  # or baking_basics or seasoning (weakest unlocked)
        "sessions": [
            {"rating": 3, "difficulty": 4, "completed": True, "quiz_score": 0.5, "notes": "too spicy"},
            {"rating": 4, "difficulty": 3, "completed": True, "quiz_score": 0.7, "notes": ""},
            {"rating": 5, "difficulty": 2, "completed": True, "quiz_score": 0.9, "notes": ""},
        ]
    },
    {
        "name": "Advanced Amateur",
        "skill_vector": {
            "knife_safety": 0.7, "heat_control": 0.6, "seasoning": 0.5,
            "stir_fry": 0.5, "baking_basics": 0.4, "timing": 0.3,
            "sauce": 0.2, "plating": 0.0
        },
        "expected_first_skill": "sauce",  # weakest among unlocked
        "sessions": [
            {"rating": 4, "difficulty": 3, "completed": True, "quiz_score": 0.8, "notes": ""},
            {"rating": 5, "difficulty": 3, "completed": True, "quiz_score": 0.9, "notes": ""},
            {"rating": 4, "difficulty": 4, "completed": True, "quiz_score": 0.7, "notes": ""},
        ]
    }
]


def run_curriculum_test():
    """Run curriculum progression tests for all personas."""
    results = {"personas": [], "summary": {}}
    total_violations = 0
    total_checks = 0
    total_skill_gains = 0

    for persona in PERSONAS:
        print(f"  Testing: {persona['name']}...")
        persona_result = {
            "name": persona["name"],
            "sessions": [],
            "violations": 0,
            "skill_progression": []
        }

        # Build a mock profile
        profile = {
            "user_id": f"eval_{persona['name'].lower().replace(' ', '_')}",
            "name": persona["name"],
            "skill_vector": dict(persona["skill_vector"]),
            "taste_prefs": {"spicy": 0.5, "sweet": 0.5, "sour": 0.5, "salty": 0.5, "umami": 0.5},
            "constraints": {"dietary": [], "equipment": ["stove", "oven"], "time_budget_minutes": 45},
            "experience_level": "beginner",
            "completed_lessons": [],
            "current_level": 1,
            "total_sessions": 0
        }

        # Record initial state
        initial_unlocked = get_unlocked_skills(profile["skill_vector"])
        persona_result["initial_unlocked"] = initial_unlocked

        # Run sessions
        for i, feedback in enumerate(persona["sessions"]):
            session_info = {}

            # Select lesson
            lesson = select_lesson(profile["skill_vector"], profile["completed_lessons"])
            if lesson is None:
                session_info["status"] = "no_lesson_available"
                persona_result["sessions"].append(session_info)
                continue

            session_info["lesson"] = lesson["id"]
            session_info["target_skill"] = lesson["skill"]
            session_info["difficulty"] = lesson["difficulty"]

            # CHECK: Is the selected skill actually unlocked?
            unlocked = get_unlocked_skills(profile["skill_vector"])
            total_checks += 1
            if lesson["skill"] not in unlocked:
                session_info["violation"] = "PREREQUISITE_VIOLATION"
                session_info["detail"] = f"{lesson['skill']} selected but not unlocked. Unlocked: {unlocked}"
                persona_result["violations"] += 1
                total_violations += 1
                print(f"    ⚠️ VIOLATION in session {i+1}: {session_info['detail']}")
            else:
                session_info["violation"] = None

            # Record pre-update skill
            old_skill = profile["skill_vector"].get(lesson["skill"], 0)
            session_info["pre_skill"] = old_skill

            # Apply feedback
            profile = update_profile(profile, feedback, lesson)

            # Record post-update skill
            new_skill = profile["skill_vector"].get(lesson["skill"], 0)
            session_info["post_skill"] = new_skill
            session_info["skill_gain"] = new_skill - old_skill
            total_skill_gains += (new_skill - old_skill)

            # Check newly unlocked skills
            new_unlocked = get_unlocked_skills(profile["skill_vector"])
            newly_unlocked = set(new_unlocked) - set(unlocked)
            if newly_unlocked:
                session_info["newly_unlocked"] = list(newly_unlocked)
                print(f"    🔓 Session {i+1}: Unlocked {newly_unlocked}")

            persona_result["sessions"].append(session_info)
            persona_result["skill_progression"].append(dict(profile["skill_vector"]))

        persona_result["final_unlocked"] = get_unlocked_skills(profile["skill_vector"])
        persona_result["skills_gained"] = len(persona_result["final_unlocked"]) - len(initial_unlocked)
        results["personas"].append(persona_result)

        print(f"    Sessions: {len(persona['sessions'])}, Violations: {persona_result['violations']}, "
              f"New skills unlocked: {persona_result['skills_gained']}")

    # Summary
    results["summary"] = {
        "total_personas": len(PERSONAS),
        "total_checks": total_checks,
        "total_violations": total_violations,
        "violation_rate": total_violations / total_checks if total_checks > 0 else 0,
        "avg_skill_gain_per_session": total_skill_gains / total_checks if total_checks > 0 else 0,
        "pass": total_violations == 0
    }

    print(f"\n  RESULTS: {total_violations}/{total_checks} prerequisite violations "
          f"({results['summary']['violation_rate']*100:.1f}% violation rate)")
    print(f"  {'✅ PASS' if total_violations == 0 else '❌ FAIL'}")

    return results
